import os
import sys
from Backend.Automation import WakeWordDetection

def main():
    try:
        print("Starting KAI Assistant...")
        print("Listening for wake words:")
        print("- 'wake up kai'")
        print("- 'hey kai'")
        print("(and other standard wake words)")
        WakeWordDetection()
    except KeyboardInterrupt:
        print("\nShutting down KAI Assistant...")
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main() 