import requests
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
from datetime import datetime, timedelta
import json
import os
from dotenv import dotenv_values
import socket
import urllib.request
import platform
import psutil
import speedtest

class WeatherSystem:
    def __init__(self):
        self.env_vars = dotenv_values(".env")
        self.weather_api_key = self.env_vars.get("WeatherAPIKey")
        self.geolocator = Nominatim(user_agent="my_assistant")
        self.cached_locations = {}
        self.cached_weather = {}
        self.cache_duration = timedelta(minutes=30)
        self.user_location = None
        
        # Create cache directory
        os.makedirs('Data/weather_cache', exist_ok=True)
        
        # Initialize user location
        self.update_user_location()
        
    def update_user_location(self):
        """Get user's current location using multiple IP services and geolocation"""
        ip_services = [
            {
                'ip_url': 'https://api.ipify.org?format=json',
                'location_url': 'https://ipapi.co/{}/json/'
            },
            {
                'ip_url': 'https://api.myip.com',
                'location_url': 'https://ip-api.com/json/{}'
            },
            {
                'ip_url': 'https://api64.ipify.org?format=json',
                'location_url': 'https://freegeoip.app/json/{}'
            }
        ]
        
        for service in ip_services:
            try:
                # Get IP address
                ip_response = requests.get(service['ip_url'], timeout=5)
                if ip_response.status_code == 200:
                    ip_data = ip_response.json()
                    ip = ip_data.get('ip')
                    
                    # Get location data
                    location_url = service['location_url'].format(ip)
                    location_response = requests.get(location_url, timeout=5)
                    if location_response.status_code == 200:
                        data = location_response.json()
                        
                        # Extract location data (handle different API formats)
                        self.user_location = {
                            'name': f"{data.get('city', '')} {data.get('country_name', data.get('country', ''))}".strip(),
                            'lat': data.get('latitude', data.get('lat')),
                            'lon': data.get('longitude', data.get('lon')),
                            'city': data.get('city'),
                            'state': data.get('region', data.get('regionName')),
                            'country': data.get('country_name', data.get('country')),
                            'timezone': data.get('timezone'),
                            'ip': ip
                        }
                        
                        # Validate the data
                        if self.user_location['lat'] and self.user_location['lon']:
                            # Reverse geocode to get detailed address
                            location = self.geolocator.reverse((self.user_location['lat'], self.user_location['lon']), exactly_one=True)
                            if location:
                                address = location.raw.get('address', {})
                                self.user_location.update({
                                    'city': address.get('city', self.user_location['city']),
                                    'state': address.get('state', self.user_location['state']),
                                    'country': address.get('country', self.user_location['country']),
                                    'postcode': address.get('postcode', ''),
                                    'road': address.get('road', ''),
                                    'neighbourhood': address.get('neighbourhood', '')
                                })
                            return self.user_location
                        
            except requests.exceptions.RequestException as e:
                print(f"Service {service['ip_url']} failed: {str(e)}")
                continue
            except Exception as e:
                print(f"Error with service {service['ip_url']}: {str(e)}")
                continue
        
        # Fallback to default location if all services fail
        print("Using fallback location data")
        self.user_location = {
            'name': "Unknown Location",
            'lat': 0,
            'lon': 0,
            'city': "Unknown City",
            'state': "Unknown State",
            'country': "Unknown Country",
            'timezone': "Unknown",
            'ip': "Unknown"
        }
        return self.user_location

    def get_system_info(self):
        """Get detailed system and network information"""
        try:
            # Get CPU information
            cpu_freq = psutil.cpu_freq()
            cpu_freq_current = f"{cpu_freq.current/1000:.1f}GHz" if cpu_freq else "Unknown"
            cpu_cores = psutil.cpu_count(logical=False)
            cpu_threads = psutil.cpu_count(logical=True)
            
            # Get memory information
            memory = psutil.virtual_memory()
            total_memory = f"{memory.total//(1024**3)}GB"
            available_memory = f"{memory.available//(1024**3)}GB"
            
            # Get disk information
            disk = psutil.disk_usage('/')
            total_disk = f"{disk.total//(1024**3)}GB"
            free_disk = f"{disk.free//(1024**3)}GB"
            
            # Get network interfaces
            network_info = []
            for interface, addresses in psutil.net_if_addrs().items():
                for addr in addresses:
                    if addr.family == socket.AF_INET:  # IPv4
                        network_info.append(f"{interface}: {addr.address}")
            
            info = {
                'system': f"{platform.system()} {platform.release()}",
                'machine': platform.machine(),
                'processor': platform.processor(),
                'cpu_usage': psutil.cpu_percent(),
                'cpu_freq': cpu_freq_current,
                'cpu_cores': cpu_cores,
                'cpu_threads': cpu_threads,
                'memory_usage': memory.percent,
                'total_memory': total_memory,
                'available_memory': available_memory,
                'total_disk': total_disk,
                'free_disk': free_disk,
                'hostname': socket.gethostname(),
                'local_ip': network_info,
                'boot_time': datetime.fromtimestamp(psutil.boot_time()).strftime('%Y-%m-%d %H:%M:%S')
            }
            return info
        except Exception as e:
            print(f"Error getting system info: {str(e)}")
            return None

    def get_network_speed(self):
        """Test network speed"""
        try:
            st = speedtest.Speedtest()
            download_speed = st.download() / 1_000_000  # Convert to Mbps
            upload_speed = st.upload() / 1_000_000  # Convert to Mbps
            ping = st.results.ping
            return {
                'download': round(download_speed, 2),
                'upload': round(upload_speed, 2),
                'ping': round(ping, 2)
            }
        except Exception as e:
            print(f"Error testing network speed: {str(e)}")
            return None

    def get_current_location_weather(self):
        """Get weather for user's current location"""
        if not self.user_location:
            self.update_user_location()
        
        if self.user_location:
            weather_data = self.get_weather(self.user_location['name'])
            return f"Your current location: {self.user_location['name']}\n{weather_data}"
        return "Could not determine your location."

    def get_location_details(self, query=None):
        """Get detailed information about a location or current location"""
        try:
            if not query:
                if not self.user_location:
                    self.update_user_location()
                location_data = self.user_location
                source = "📍 Your Current Location"
                
                if location_data['city'] == "Unknown City":
                    self.update_user_location()
                    location_data = self.user_location
            else:
                location_data = self.get_location(query)
                source = f"📍 Location Information for {query}"
            
            if location_data:
                response = f"{source}:\n"
                
                if location_data['city'] != "Unknown City":
                    if location_data.get('city'):
                        response += f"🏙️ City: {location_data['city']}\n"
                    if location_data.get('state'):
                        response += f"🏰 State/Region: {location_data['state']}\n"
                    if location_data.get('country'):
                        response += f"🌐 Country: {location_data['country']}\n"
                    if location_data.get('timezone'):
                        response += f"🕒 Timezone: {location_data['timezone']}\n"
                    response += f"📌 Coordinates: {location_data['lat']}, {location_data['lon']}\n"
                    if location_data.get('postcode'):
                        response += f"🏷️ Postcode: {location_data['postcode']}\n"
                    if location_data.get('road'):
                        response += f"🛣️ Road: {location_data['road']}\n"
                    if location_data.get('neighbourhood'):
                        response += f"🏘️ Neighbourhood: {location_data['neighbourhood']}\n"
                else:
                    response += "❗ Could not determine exact location.\n"
                
                # Add local time with emoji
                local_time = datetime.now()
                response += f"⏰ Local Time: {local_time.strftime('%I:%M %p, %A %B %d, %Y')}\n\n"
                
                # Add system information with better formatting
                sys_info = self.get_system_info()
                if sys_info:
                    response += self.get_system_info_string()
                
                return response
            return "Location information not available."
            
        except Exception as e:
            print(f"Error getting location details: {str(e)}")
            return "Error retrieving location information. However, I can show you system information:\n" + \
                   self.get_system_info_string()

    def get_system_info_string(self):
        """Get formatted system information string"""
        try:
            sys_info = self.get_system_info()
            if sys_info:
                response = "💻 System Information:\n"
                response += f"🖥️ OS: {sys_info['system']}\n"
                response += f"⚡ Processor: {sys_info['processor']}\n"
                response += f"🔄 CPU Cores: {sys_info['cpu_cores']} physical, {sys_info['cpu_threads']} logical\n"
                response += f"⚡ CPU Frequency: {sys_info['cpu_freq']}\n"
                response += f"📊 CPU Usage: {sys_info['cpu_usage']}%\n"
                response += f"🧮 Memory: {sys_info['available_memory']} available of {sys_info['total_memory']}\n"
                response += f"💾 Disk Space: {sys_info['free_disk']} free of {sys_info['total_disk']}\n"
                response += f"🏷️ Computer Name: {sys_info['hostname']}\n"
                response += "🌐 Network Interfaces:\n"
                for ip in sys_info['local_ip']:
                    response += f"   • {ip}\n"
                response += f"⏰ System Uptime Since: {sys_info['boot_time']}"
                return response
            return "System information not available."
        except Exception as e:
            print(f"Error getting system info string: {str(e)}")
            return "Could not retrieve system information."

    def get_location(self, query):
        """Get detailed location information"""
        try:
            # Clean up the query
            query = query.strip()
            if not query:
                return None
            
            # Check cache first
            if query in self.cached_locations:
                location_data, timestamp = self.cached_locations[query]
                if datetime.now() - timestamp < self.cache_duration:
                    return location_data
            
            # Try with different geocoding options
            location = None
            try:
                # Try with default settings
                location = self.geolocator.geocode(query, addressdetails=True)
            except:
                try:
                    # Try with more lenient settings
                    location = self.geolocator.geocode(query, addressdetails=True, exactly_one=False)[0]
                except:
                    pass
            
            if location:
                location_data = {
                    'name': location.raw.get('display_name'),
                    'lat': location.latitude,
                    'lon': location.longitude,
                    'address': location.raw.get('address', {}),
                    'type': location.raw.get('type'),
                    'country': location.raw.get('address', {}).get('country'),
                    'city': location.raw.get('address', {}).get('city') or query.title(),
                    'state': location.raw.get('address', {}).get('state'),
                    'postcode': location.raw.get('address', {}).get('postcode', ''),
                    'road': location.raw.get('address', {}).get('road', ''),
                    'neighbourhood': location.raw.get('address', {}).get('neighbourhood', '')
                }
                
                # Cache the result
                self.cached_locations[query] = (location_data, datetime.now())
                return location_data
            
            # Try alternative geocoding service if first one fails
            try:
                url = f"http://api.openweathermap.org/geo/1.0/direct?q={query}&limit=1&appid={self.weather_api_key}"
                response = requests.get(url, timeout=5)
                data = response.json()
                
                if data and len(data) > 0:
                    location_data = {
                        'name': data[0].get('name'),
                        'lat': data[0].get('lat'),
                        'lon': data[0].get('lon'),
                        'country': data[0].get('country'),
                        'city': data[0].get('name'),
                        'state': data[0].get('state')
                    }
                    self.cached_locations[query] = (location_data, datetime.now())
                    return location_data
            except:
                pass
            
            return None
            
        except Exception as e:
            print(f"Location error: {str(e)}")
            return None
    
    def get_weather(self, location_query, forecast_days=0):
        """Get current weather or forecast"""
        try:
            # Handle empty location query for current location
            if not location_query or location_query.strip() == "":
                if not self.user_location:
                    self.update_user_location()
                location = self.user_location
            else:
                # Get location coordinates
                location = self.get_location(location_query)
            
            if not location:
                return "Location not found. Please try again with a valid location."
            
            lat, lon = location['lat'], location['lon']
            cache_key = f"{lat},{lon},{forecast_days}"
            
            # Check cache
            if cache_key in self.cached_weather:
                weather_data, timestamp = self.cached_weather[cache_key]
                if datetime.now() - timestamp < self.cache_duration:
                    return self._format_weather_response(weather_data, location, forecast_days)
            
            # Make API request with better error handling
            try:
                if forecast_days > 0:
                    url = f"https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={self.weather_api_key}&units=metric"
                else:
                    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={self.weather_api_key}&units=metric"
                
                response = requests.get(url, timeout=10)  # Add timeout
                response.raise_for_status()  # Raise exception for bad status codes
                weather_data = response.json()
                
                # Verify weather data structure
                if 'main' not in weather_data and 'list' not in weather_data:
                    raise ValueError("Invalid weather data received")
                
                # Cache the result
                self.cached_weather[cache_key] = (weather_data, datetime.now())
                
                return self._format_weather_response(weather_data, location, forecast_days)
                
            except requests.exceptions.RequestException as e:
                print(f"Weather API error: {str(e)}")
                return "Sorry, I couldn't fetch the weather information. Please check your internet connection."
            except Exception as e:
                print(f"Weather processing error: {str(e)}")
                return "Error processing weather data."
            
        except Exception as e:
            print(f"Weather error: {str(e)}")
            return "Sorry, I couldn't fetch the weather information."
    
    def _format_weather_response(self, weather_data, location, forecast_days):
        """Format weather data into readable response"""
        try:
            if forecast_days > 0:
                return self._format_forecast(weather_data, location)
            else:
                return self._format_current_weather(weather_data, location)
        except Exception as e:
            print(f"Formatting error: {str(e)}")
            return "Error formatting weather data."
    
    def _format_current_weather(self, weather_data, location):
        """Format current weather data with enhanced information"""
        try:
            temp = round(weather_data['main']['temp'])
            feels_like = round(weather_data['main']['feels_like'])
            humidity = weather_data['main']['humidity']
            wind_speed = weather_data['wind']['speed']
            description = weather_data['weather'][0]['description']
            
            location_name = location.get('city') or location.get('name')
            
            response = f"🌡️ Current weather in {location_name}:\n"
            response += f"🌡️ Temperature: {temp}°C (feels like {feels_like}°C)\n"
            response += f"🌤️ Condition: {description.capitalize()}\n"
            response += f"💧 Humidity: {humidity}%\n"
            response += f"💨 Wind Speed: {wind_speed} m/s\n"
            
            # Additional weather data if available
            if 'pressure' in weather_data['main']:
                response += f"⏲️ Pressure: {weather_data['main']['pressure']} hPa\n"
            if 'visibility' in weather_data:
                response += f"👁️ Visibility: {weather_data['visibility']/1000:.1f} km\n"
            if 'clouds' in weather_data and 'all' in weather_data['clouds']:
                response += f"☁️ Cloud Cover: {weather_data['clouds']['all']}%\n"
            if 'sys' in weather_data and all(k in weather_data['sys'] for k in ['sunrise', 'sunset']):
                sunrise = datetime.fromtimestamp(weather_data['sys']['sunrise']).strftime('%I:%M %p')
                sunset = datetime.fromtimestamp(weather_data['sys']['sunset']).strftime('%I:%M %p')
                response += f"🌅 Sunrise: {sunrise}\n"
                response += f"🌇 Sunset: {sunset}"
            
            return response
            
        except Exception as e:
            print(f"Error formatting weather: {str(e)}")
            return "Error formatting weather data."
    
    def _format_forecast(self, weather_data, location):
        """Format forecast weather data"""
        location_name = location.get('city') or location.get('name')
        response = f"Weather forecast for {location_name}:\n\n"
        
        # Group forecasts by day
        daily_forecasts = {}
        for item in weather_data['list']:
            date = datetime.fromtimestamp(item['dt']).strftime('%Y-%m-%d')
            if date not in daily_forecasts:
                daily_forecasts[date] = []
            daily_forecasts[date].append(item)
        
        # Format each day's forecast
        for date, forecasts in list(daily_forecasts.items())[:5]:  # Show 5 days
            day = datetime.strptime(date, '%Y-%m-%d').strftime('%A')
            temps = [f['main']['temp'] for f in forecasts]
            avg_temp = round(sum(temps) / len(temps))
            conditions = [f['weather'][0]['description'] for f in forecasts]
            main_condition = max(set(conditions), key=conditions.count)
            
            response += f"{day}:\n"
            response += f"Average Temperature: {avg_temp}°C\n"
            response += f"Conditions: {main_condition.capitalize()}\n\n"
        
        return response
    
    def get_nearby_places(self, location_query, place_type, radius=1000):
        """Find nearby places of interest"""
        try:
            location = self.get_location(location_query)
            if not location:
                return "Location not found."
            
            # Use OpenStreetMap Overpass API for nearby places
            overpass_url = "http://overpass-api.de/api/interpreter"
            query = f"""
            [out:json];
            (
              node["amenity"="{place_type}"](around:{radius},{location['lat']},{location['lon']});
              way["amenity"="{place_type}"](around:{radius},{location['lat']},{location['lon']});
              relation["amenity"="{place_type}"](around:{radius},{location['lat']},{location['lon']});
            );
            out center;
            """
            
            response = requests.post(overpass_url, data=query)
            data = response.json()
            
            if not data.get('elements'):
                return f"No {place_type}s found nearby."
            
            response = f"Nearby {place_type}s around {location['name']}:\n\n"
            for place in data['elements'][:5]:  # Show top 5 results
                if 'tags' in place:
                    name = place['tags'].get('name', 'Unnamed')
                    if 'center' in place:
                        lat, lon = place['center']['lat'], place['center']['lon']
                    else:
                        lat, lon = place['lat'], place['lon']
                    distance = round(geodesic((location['lat'], location['lon']), (lat, lon)).meters)
                    response += f"- {name} ({distance}m away)\n"
            
            return response
            
        except Exception as e:
            print(f"Nearby places error: {str(e)}")
            return f"Sorry, I couldn't find nearby {place_type}s."