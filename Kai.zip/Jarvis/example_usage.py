from chrome_automation import ChromeAutomation
from selenium.webdriver.common.by import By

# Create an instance
bot = ChromeAutomation()

try:
    # Login to a website
    bot.navigate_to("https://example.com/login")
    
    # Fill login form
    form_data = {
        "username": "your_username",
        "password": "your_password"
    }
    bot.fill_form(form_data)
    
    # Wait for and click login button
    login_button = bot.wait_and_find_element(By.ID, "login-button")
    if login_button:
        login_button.click()
    
    # Save cookies for future sessions
    bot.save_cookies("login_cookies.json")
    
finally:
    bot.close() 