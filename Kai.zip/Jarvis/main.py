from Frontend.GUI import (
    GraphicalUserInterface,
    SetAssistantStatus,
    ShowTextToScreen,
    TempDirectoryPath,
    SetMicrophoneStatus,
    AnswerModifier,
    QueryModifier,
    GetMicrophoneStatus,
    GetAssistantStatus
)
from Backend.Model import FirstLayerDMM
from threading import Thread
from json import load, dump
from Backend.RealtimeSearchEngine import RealtimeSearchEngine
from Backend.Automation import Automation
from Backend.SpeechToText import SpeechRecognition
from Backend.Chatbot import ChatBot 
from Backend.TextToSpeech import TextToSpeech
from dotenv import dotenv_values
from Backend.TypeQuery import TypeQuery
from Backend.Basic import ChromeCode
from Backend.__init__ import KnownApps
import pygetwindow as gw
import keyboard
from asyncio import run
from time import sleep 
import subprocess
import threading
import json 
import os
import pvporcupine
import pyaudio
import struct
import datetime
from weather_system import WeatherSystem
import geocoder
import re
import folium
from geopy.geocoders import Nominatim
from geopy.adapters import AioHTTPAdapter
import socket
from Backend.screenshot_system import handle_screenshot_command
from Backend.reminder_system import handle_reminder_command
import random


env_vars = dotenv_values(".env") 
Username = env_vars.get("Username")
WakeWordAPIKey = env_vars.get("WakeWordAPIKey")
Assistantname = env_vars.get("Assistantname")
DefaultMessage = f'''{Username} : Hello {Assistantname}, How are you?
{Assistantname} : Welcome {Username}. I am doing well. How may i help you?'''

query = "What's your name?"

def execute_chrome_command(query):
    chrome_command = ChromeCode(query)
    if chrome_command:
        print(f"Executing Chrome command: {chrome_command}")
        keyboard.press_and_release(chrome_command)
        return True
    return False

# Example usage
commands = ["open new tab", "open incognito window"]
for command in commands:
    if "chrome" in command:
        execute_chrome_command(command)

# Call TypeQuery function
TypeQuery(query)
subprocesses = []
Functions = ["open", "close", "play", "system", "content", "google search", "youtube search", "whatsapp message", "whatsapp group message", "whatsapp call"]

def ShowDefaultChatIfNoChats():
    File = open(r'C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json', "r", encoding='utf-8')
    if len(File.read()) < 5:
        with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
            file.write("")
        with open(TempDirectoryPath('Responses.data'), 'w', encoding='utf-8') as file:
            file.write(DefaultMessage)

def ReadChatLogJson():
    with open(r'C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json', 'r', encoding='utf-8') as file:
        chatlog_data = json.load(file)
    return chatlog_data

def ChatLogIntegration():
    json_data = ReadChatLogJson()
    formatted_chatlog = ""
    for entry in json_data:
        if entry["role"] == "user":
            formatted_chatlog += f"user: {entry['content']}\n"
        elif entry["role"] == "assistant":
            formatted_chatlog += f"Assistant: {entry['content']}\n"
    formatted_chatlog = formatted_chatlog.replace("User", Username + " ")
    formatted_chatlog = formatted_chatlog.replace("Assistant", Assistantname + " ") 

    with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
        file.write(AnswerModifier(formatted_chatlog))

def ShowChatsOnGUI():
    File = open(TempDirectoryPath('Database.data'), "r", encoding='utf-8')
    Data = File.read()
    if len(str(Data)) > 0:
        lines = Data.split('\n')
        result = '\n'.join(lines)  
        File.close()
        File = open(TempDirectoryPath('Responses.data'), "w", encoding='utf-8')
        File.write(result)
        File.close() 

def InitialExecution():
    SetMicrophoneStatus("False")
    ShowTextToScreen("")
    ShowDefaultChatIfNoChats()
    ChatLogIntegration()
    ShowChatsOnGUI()

InitialExecution()

weather_system = WeatherSystem()

def get_email_confirmation(message):
    """Get a random, natural-sounding email confirmation message"""
    try:
        # Extract recipient and subject from the message
        recipient = ""
        subject = ""
        
        # More robust pattern matching
        if "✓" in message:  # Successful email
            # Try different patterns to extract info
            recipient_patterns = [
                r'sent.*?to\s+([^\s]+@[^\s]+)',  # matches email addresses
                r'to\s+([^\s]+@[^\s]+)',
                r'recipient:\s*([^\n]+)',
                r'to:\s*([^\n]+)'
            ]
            
            subject_patterns = [
                r'about\s+["\'](.+?)["\']',
                r'subject:\s*([^\n]+)',
                r'regarding\s+["\'](.+?)["\']',
                r'about:\s*([^\n]+)'
            ]
            
            # Try to find recipient
            for pattern in recipient_patterns:
                if match := re.search(pattern, message.lower()):
                    recipient = match.group(1).strip()
                    break
            
            # Try to find subject
            for pattern in subject_patterns:
                if match := re.search(pattern, message.lower()):
                    subject = match.group(1).strip()
                    break
            
            # If we found both recipient and subject
            if recipient and subject:
                confirmations = [
                    f"Email sent! Your message to {recipient} about '{subject}' is on its way! 📧",
                    f"Done and done! Just sent that email to {recipient} regarding '{subject}'.",
                    f"Message delivered! {recipient} will get your email about '{subject}' shortly.",
                    f"Success! Your email about '{subject}' has been sent to {recipient}.",
                    f"All set! I've sent your message to {recipient} about '{subject}'.",
                    f"Email successfully delivered to {recipient}! They'll see your message about '{subject}' soon.",
                    f"Great! Your email about '{subject}' is now in {recipient}'s inbox.",
                    f"Mission accomplished! Email sent to {recipient} regarding '{subject}'.",
                    f"Perfect timing! Just sent that email to {recipient} about '{subject}'.",
                    f"Email away! {recipient} will receive your message about '{subject}' shortly."
                ]
                return random.choice(confirmations)
            else:
                # Fallback if we couldn't extract both pieces
                return f"✓ Email sent successfully! {message}"
                
        else:  # Error messages
            error_messages = [
                "Oops! Looks like something went wrong with that email.",
                "I couldn't send that email. Let's try again?",
                "Sorry about this, but the email didn't go through.",
                "That email didn't quite make it. Want to try again?",
                "Having trouble with that email. Mind if we give it another shot?",
                "Email sending hiccupped. Should we try once more?",
                "Hmm, the email didn't send. Let's try that again.",
                "Technical glitch with the email. Care to retry?",
                "Email system is being stubborn. Shall we try again?",
                "That email didn't quite work out. Another attempt?"
            ]
            
            error_details = message.split("email:")[1].strip() if "email:" in message else message
            return f"{random.choice(error_messages)} ({error_details})"
            
    except Exception as e:
        print(f"Error formatting email confirmation: {e}")
        return message  # Return original message if parsing fails

def MainExecution():
    TaskExecution = False 
    ImageExecution = False
    ImageGenerationQuery = ""
    
    SetAssistantStatus("Listening...")
    try:
        Query = SpeechRecognition()
        if not Query or Query.strip() == "":
            SetAssistantStatus("Sorry, I couldn't hear that. Please try again.")
            TextToSpeech("Sorry, I couldn't hear that. Please try again.")
            return False
            
        print(f"Recognized Speech: {Query}")
        ShowTextToScreen(f"{Username} : {Query}")
        SetAssistantStatus("Thinking ...")

        # Handle email commands
        email_keywords = ['send email', 'write email', 'compose email', 'email to', 'mail to']
        if any(keyword in Query.lower() for keyword in email_keywords):
            try:
                from Backend.email_system import AdvancedEmailSystem
                email_system = AdvancedEmailSystem()
                result = email_system.handle_email_command(Query)
                confirmation = get_email_confirmation(result)
                ShowTextToScreen(f"{Assistantname}: {confirmation}")
                TextToSpeech(confirmation.replace("📧", ""))
                return True
            except Exception as e:
                error_msg = f"Error with email: {str(e)}"
                ShowTextToScreen(f"{Assistantname}: {error_msg}")
                TextToSpeech("Sorry, there was an error with the email.")
                return False

        # Handle Chrome commands
        chrome_keywords = [
            "chrome", "browser", "tab", "incognito", "history",
            "window", "refresh", "reload", "bookmark", "downloads",
            "new tab", "close tab", "zoom", "search", "developer",
            "print", "save", "full screen", "mute", "pin"
        ]
        
        if any(keyword in Query.lower() for keyword in chrome_keywords):
            try:
                from Backend.Basic import handle_chrome_command
                result = handle_chrome_command(Query)
                ShowTextToScreen(f"{Assistantname}: {result}")
                TextToSpeech(result.replace("✓", "").replace("⚠️", "").replace("❌", ""))
                return True
            except Exception as e:
                error_msg = f"Chrome automation error: {str(e)}"
                ShowTextToScreen(f"{Assistantname}: {error_msg}")
                TextToSpeech("Sorry, there was an error with Chrome automation.")
                return False

        # Handle reminder commands
        if any(keyword in Query.lower() for keyword in [
            "set reminder", "remind me", "create reminder", "add reminder",
            "notify me", "alert me", "schedule reminder", "in", "after"
        ]):
            try:
                SetAssistantStatus("Setting reminder...")
                reminder_response = handle_reminder_command(Query)
                
                if reminder_response:
                    # Extract time and task from response
                    time_str = reminder_response.get('time', '')
                    task = reminder_response.get('task', '')
                    
                    # Format confirmation messages
                    if "seconds" in time_str:
                        confirmations = [
                            f"Setting quick reminder for {task} in {time_str}! ⏰",
                            f"I'll remind you about {task} in {time_str}! ⏰",
                            f"Quick reminder set: {task} in {time_str}! ⏰",
                            f"Got it! Reminding you about {task} in {time_str}! ⏰"
                        ]
                    else:
                        confirmations = [
                            f"I'll remind you to {task} at {time_str}. ⏰",
                            f"Got it! I've set a reminder for {task} at {time_str}. ⏰",
                            f"Reminder set! I'll notify you about {task} at {time_str}. ⏰",
                            f"All set! You'll be reminded about {task} at {time_str}. ⏰",
                            f"Consider it done! I'll remind you about {task} at {time_str}. ⏰"
                        ]
                    
                    confirmation = random.choice(confirmations)
                    ShowTextToScreen(f"{Assistantname}: {confirmation}")
                    TextToSpeech(confirmation.replace("⏰", ""))
                    return True
                else:
                    error_messages = [
                        "I couldn't set that reminder. Could you try saying it differently?",
                        "Sorry, I had trouble with that reminder. Can you rephrase it?",
                        "I didn't quite catch when to remind you. Mind trying again?",
                        "The reminder format wasn't clear to me. Could you try again?"
                    ]
                    error_msg = random.choice(error_messages)
                    ShowTextToScreen(f"{Assistantname}: {error_msg}")
                    TextToSpeech(error_msg)
                    return False
                    
            except Exception as e:
                error_msg = f"Sorry, I ran into an issue setting your reminder: {str(e)}"
                ShowTextToScreen(f"{Assistantname}: {error_msg}")
                TextToSpeech("Sorry, there was an error setting your reminder.")
                SetAssistantStatus("Available...")
                return False

        # Handle WhatsApp commands
        whatsapp_keywords = [
            "whatsapp", "message", "call", "text", "dial",
            "create group", "add contact", "save number", "list contacts"
        ]
        if any(keyword in Query.lower() for keyword in whatsapp_keywords):
            try:
                from Backend.whatsapp_system import WhatsAppSystem
                whatsapp = WhatsAppSystem()
                result = whatsapp.handle_command(Query)
                # Handle WhatsApp confirmations
                if "list contacts" in Query.lower():
                    ShowTextToScreen(f"{Assistantname}: Here are your saved contacts:\n{result}")
                    TextToSpeech("Here are your saved contacts. You can see them on screen.")
                    return True
                elif "Message sent successfully" in result:
                    confirmation = f"Great! {result} The message is on its way! 💬"
                    ShowTextToScreen(f"{Assistantname}: {confirmation}")
                    TextToSpeech(confirmation.replace("💬", ""))
                    return True
                else:
                    ShowTextToScreen(f"{Assistantname}: {result}")
                    TextToSpeech(result)
                    return True
            except Exception as e:
                error_msg = f"WhatsApp error: {str(e)}"
                ShowTextToScreen(f"{Assistantname}: {error_msg}")
                TextToSpeech("Sorry, there was an error with WhatsApp.")
                return False

        # Handle location commands
        if "location" in Query.lower():
            try:
                location_response = process_location_command(Query)
                ShowTextToScreen(f"{Assistantname}: {location_response}")
                TextToSpeech(location_response)
                return True
            except Exception as e:
                error_msg = f"Location error: {str(e)}"
                ShowTextToScreen(f"{Assistantname}: {error_msg}")
                TextToSpeech("Sorry, there was an error getting the location.")
                return False

        # If no specific command matched, use AI model for response
        Decision = FirstLayerDMM(Query)
        print(f"\nDecision: {Decision}\n")

        # Handle general responses
        if len(Decision) == 1 and Decision[0].startswith("general"):
            message = Decision[0].replace("general ", "")
            ShowTextToScreen(f"{Assistantname}: {message}")
            TextToSpeech(message)
            return True

        G = any([i for i in Decision if i.startswith("general")])
        R = any([i for i in Decision if i.startswith("realtime")])

        Mearged_query = " and ".join(
            [" ".join(i.split()[1:]) for i in Decision if i.startswith("general") or i.startswith("realtime")]
        )
        
        for queries in Decision:
            if "generate " in queries:
                ImageGenerationQuery = str(queries)
                ImageExecution = True

        for queries in Decision:
            if TaskExecution == False:
                if any(queries.startswith(func) for func in Functions):
                    run(Automation(list(Decision)))           
                    TaskExecution = True
                elif "whatsapp" in queries:
                    run(Automation([queries]))  # Executes WhatsApp automation
                    TaskExecution = True
                
        if ImageExecution == True:
            with open(r"Frontend/Files/ImageGeneration.data", "w") as file:
                file.write(f"{ImageGenerationQuery}, True")
            print(f"Written to ImageGeneration.data: {ImageGenerationQuery}, True")

            try:
                p1 = subprocess.Popen(['python', r'Backend/ImageGeneration.py'],
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                      stdin=subprocess.PIPE, shell=True)
                subprocesses.append(p1)
                print("Started ImageGeneration.py subprocess")
            except FileNotFoundError:
                print("Error starting ImageGeneration.py: FileNotFoundError")
            except Exception as e:
                print("Error starting ImageGeneration.py:", e)

        if G and R or R:
            try:
                SetAssistantStatus("Searching...")
                Answer = RealtimeSearchEngine(QueryModifier(Mearged_query))
                ShowTextToScreen(f"{Assistantname} : {Answer}")
                SetAssistantStatus("Answering...")
                TextToSpeech(Answer)
                return True
            except Exception as e:
                print("Error during real-time search:", e)
                SetAssistantStatus("Error during real-time search")
                return False

        else:
            for Queries in Decision:
                if "general" in Queries or "realtime" in Queries:
                    try:
                        SetAssistantStatus("Thinking...")
                        QueryFinal = Queries.replace("general ", "")
                        Answer = ChatBot(QueryModifier(QueryFinal))
                        ShowTextToScreen(f"{Assistantname} : {Answer}")
                        SetAssistantStatus("Answering...")
                        TextToSpeech(Answer)
                        return True
                    except Exception as e:
                        print("Error during general query processing:", e)
                        SetAssistantStatus("Error during general query processing")
                        return False
                
                elif "realtime" in Queries:
                    try:
                        SetAssistantStatus("Searching...")
                        QueryFinal = Queries.replace("realtime ", "")
                        Answer = RealtimeSearchEngine(QueryModifier(QueryFinal))
                        ShowTextToScreen(f"{Assistantname} : {Answer}")
                        SetAssistantStatus("Answering...")
                        TextToSpeech(Answer)
                        return True
                    except Exception as e:
                        print("Error during real-time query processing:", e)
                        SetAssistantStatus("Error during real-time query processing")
                        return False
                
                elif "exit" in Queries:
                    QueryFinal = "Okay , Bye!"
                    Answer = ChatBot(QueryModifier(QueryFinal))
                    ShowTextToScreen(f"{Assistantname} : {Answer}")
                    SetAssistantStatus("Answering...")
                    TextToSpeech(Answer)
                    SetAssistantStatus("Answering...")
                    os._exit(1)
                
        if any(word in Query.lower() for word in ["screenshot", "capture screen", "take photo"]):
            screenshot_response = handle_screenshot_command(Query)
            if screenshot_response:
                return True

        return True

    except Exception as e:
        error_msg = f"Error processing speech: {str(e)}"
        print(error_msg)  # Debug print
        SetAssistantStatus("Error occurred")
        ShowTextToScreen(f"{Assistantname} : {error_msg}")
        TextToSpeech("Sorry, I encountered an error. Please try again.")
        return False

# Move these outside of MainExecution
ACCESS_KEY = WakeWordAPIKey  # Replace with your actual access key

def WakeWordDetection():
    porcupine = pvporcupine.create(access_key=ACCESS_KEY, keywords=["hey siri", "hey barista", "jarvis", "hey google", "bumblebee", "grasshopper", "ok google", "blueberry", "terminator", "alexa"])
    pa = pyaudio.PyAudio()
    audio_stream = pa.open(
        rate=porcupine.sample_rate,
        channels=1,
        format=pyaudio.paInt16,
        input=True,
        frames_per_buffer=porcupine.frame_length
    )

    while True:
        pcm = audio_stream.read(porcupine.frame_length)
        pcm = struct.unpack_from("h" * porcupine.frame_length, pcm)

        keyword_index = porcupine.process(pcm)
        if keyword_index >= 0:
            print("Wake word detected!")
            SetMicrophoneStatus("True")

def FirstThread():
    Thread(target=WakeWordDetection, daemon=True).start()
    while True:
        CurrentStatus = GetMicrophoneStatus()
        if CurrentStatus == "True":
            MainExecution()
        else:
            AIStatus = GetAssistantStatus()
            if "Available..." in AIStatus:
                sleep(0.1)
            else:
                SetAssistantStatus("Available...")

def SecondThread():
    GraphicalUserInterface()

# Move location and reminder functions outside
def get_location():
    try:
        # Initialize Nominatim geocoder
        geolocator = Nominatim(user_agent="my_assistant")
        
        # Get location using local network info first
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        
        # Get detailed location
        location = geolocator.geocode(local_ip, addressdetails=True)
        if not location:
            # Fallback to reverse geocoding using approximate coordinates
            location = geolocator.reverse("40.7128, -74.0060")  # Default to NYC if can't get exact
        
        address = location.raw.get('address', {})
        location_data = {
            'street': address.get('road', ''),
            'house_number': address.get('house_number', ''),
            'suburb': address.get('suburb', ''),
            'city': address.get('city', address.get('town', address.get('village', ''))),
            'state': address.get('state', ''),
            'country': address.get('country', ''),
            'postcode': address.get('postcode', ''),
            'lat': location.latitude,
            'lng': location.longitude
        }
        return location_data
    except Exception as e:
        print(f"Location error: {str(e)}")
        return None

def process_location_command(command):
    location = get_location()
    if location:
        address_parts = []
        if location['street'] and location['house_number']:
            address_parts.append(f"{location['house_number']} {location['street']}")
        if location['suburb']:
            address_parts.append(location['suburb'])
        if location['city']:
            address_parts.append(location['city'])
        if location['state']:
            address_parts.append(location['state'])
        if location['country']:
            address_parts.append(location['country'])
            
        address = ", ".join(filter(None, address_parts))
        return f"You are at {address}"
    return "Sorry, I couldn't determine your location at the moment."

if __name__ == "__main__":
    CURRENT_APP = ""
    try:
        CURRENT_APP = gw.getActiveWindowTitle()
    except gw.PyGetWindowException:
        CURRENT_APP = ""
    
    if CURRENT_APP and len(CURRENT_APP) > 0:
        CURRENT_APP_NAME = CURRENT_APP[-1]
        
        if CURRENT_APP_NAME in KnownApps:
            Func_ = KnownApps[CURRENT_APP_NAME]
            Output = Func_(CURRENT_APP)
            if Output != False:
                keyboard.press_and_release(Output)
    
    thread2 = threading.Thread(target=FirstThread, daemon=True)
    thread2.start()
    SecondThread()