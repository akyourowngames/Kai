# Shared utility functions to break circular imports
def show_text_to_screen(text):
    from Frontend.GUI import ShowTextToScreen
    ShowTextToScreen(text)

def set_assistant_status(status):
    from Frontend.GUI import SetAssistantStatus
    SetAssistantStatus(status) 