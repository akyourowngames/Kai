import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr
import os
from typing import Dict
from dotenv import load_dotenv
from Backend.email_contacts import ContactManager

class AdvancedEmailSystem:
    def __init__(self):
        load_dotenv()
        self.contact_manager = ContactManager()
        self.status_messages = []
        
        # Load email credentials
        self.email = os.getenv('EMAIL_ADDRESS')
        self.password = os.getenv('EMAIL_PASSWORD')
        
        if not self.email or not self.password:
            raise ValueError("Email credentials not found in .env file")

    def add_status(self, message: str):
        """Add status message to be included in response"""
        self.status_messages.append(message)

    def parse_email_command(self, command: str) -> Dict:
        """Simple but robust command parsing"""
        email_data = {
            'to': [],
            'subject': '',
            'body': ''
        }
        
        command = command.lower().strip()
        
        try:
            # Extract recipient
            if "to" in command and "subject" in command:
                recipient_part = command[command.find("to")+2:command.find("subject")].strip()
                email = self.contact_manager.get_email(recipient_part)
                if email:
                    email_data['to'].append(email)
                    self.add_status(f"✓ Recipient: {recipient_part}")
                else:
                    self.add_status(f"✗ Could not find email for: {recipient_part}")

            # Extract subject
            if "subject" in command and "body" in command:
                subject_part = command[command.find("subject")+7:command.find("body")].strip()
                email_data['subject'] = subject_part
                self.add_status(f"✓ Subject: {subject_part}")

            # Extract body
            if "body" in command:
                body_part = command[command.find("body")+4:].strip()
                email_data['body'] = body_part
                self.add_status(f"✓ Message body prepared")
            elif "subject" in command:
                remaining = command[command.find("subject")+7:].strip()
                if remaining:
                    email_data['body'] = remaining
                    self.add_status(f"✓ Message body extracted from text")

        except Exception as e:
            self.add_status(f"✗ Error parsing command: {str(e)}")

        return email_data

    def send_email(self, email_data: Dict) -> str:
        """Send email with the specified components"""
        try:
            self.add_status("Preparing email...")
            msg = MIMEMultipart()
            msg['From'] = formataddr(("Kai Assistant", self.email))
            msg['To'] = ', '.join(email_data['to'])
            msg['Subject'] = email_data['subject']
            msg.attach(MIMEText(email_data['body'], 'plain'))

            self.add_status("Connecting to email server...")
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(self.email, self.password)
                self.add_status("Sending message...")
                server.send_message(msg)

            self.add_status(f"✓ Email sent successfully to {', '.join(email_data['to'])}!")
            
            # Compile all status messages into a user-friendly response
            status_report = "\n".join(self.status_messages)
            return f"Email Status:\n{status_report}"

        except Exception as e:
            error_msg = f"✗ Failed to send email: {str(e)}"
            self.add_status(error_msg)
            return "\n".join(self.status_messages)

    def handle_email_command(self, command: str) -> str:
        """Main function to handle email commands"""
        try:
            # Reset status messages for new command
            self.status_messages = []
            self.add_status("Processing email command...")
            
            # Parse the command
            email_data = self.parse_email_command(command)
            
            # Validate required fields
            if not email_data['to']:
                return "✗ No recipient email address found. Please specify who to send the email to."
            if not email_data['subject']:
                return "✗ No subject found. Please include a subject for your email."
            if not email_data['body']:
                return "✗ No email content found. Please specify what message to send."

            # Send the email and return status
            return f"✓ Email sent successfully! Recipient: {', '.join(email_data['to'])}, Subject: {email_data['subject']}"
            
        except Exception as e:
            return f"✗ Error sending email: {str(e)}" 