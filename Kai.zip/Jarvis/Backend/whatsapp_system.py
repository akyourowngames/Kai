import pywhatkit
import pyautogui
import time
from datetime import datetime, timedelta
import webbrowser
import re
import json
import os
from dotenv import load_dotenv
from Backend.contacts_manager import ContactsManager

class WhatsAppSystem:
    def __init__(self):
        load_dotenv()
        self.contacts = ContactsManager()
        
    def get_phone_number(self, name):
        """Get phone number from saved contacts"""
        return self.contacts.get_phone_number(name)

    def add_contact(self, name, phone):
        """Add new contact"""
        self.contacts.add_contact(name, phone)
        return f"Added {name} to WhatsApp contacts"

    def send_message(self, query):
        """Send WhatsApp message"""
        try:
            # Extract recipient and message
            match = re.search(r"(?:message|send|text|msg)\s+(?:to\s+)?([a-zA-Z\s]+)(?:\s+saying\s+|\s+that\s+|\s+)(.+)", query, re.IGNORECASE)
            if not match:
                return "Could not understand the message format. Please try again."
            
            recipient, message = match.groups()
            phone = self.get_phone_number(recipient)
            
            if not phone:
                return f"Could not find phone number for {recipient}. Please add the contact first."
            
            # Calculate time for message (2 minutes from now to allow WhatsApp Web to load)
            now = datetime.now()
            send_time = now + timedelta(minutes=1)
            
            # Send message using pywhatkit
            pywhatkit.sendwhatmsg(phone, message, 
                                 send_time.hour, 
                                 send_time.minute,
                                 wait_time=15,
                                 tab_close=True)
            
            return f"Message sent successfully to {recipient}!"
            
        except Exception as e:
            return f"Error sending message: {str(e)}"

    def make_call(self, query):
        """Make WhatsApp call"""
        try:
            # Extract recipient and call type
            match = re.search(r"(?:call|dial|phone)\s+(?:to\s+)?([a-zA-Z\s]+)(?:\s+with\s+)?(video|voice)?", query, re.IGNORECASE)
            if not match:
                return "Could not understand the call format. Please try again."
            
            recipient, call_type = match.groups()
            call_type = call_type or "voice"  # Default to voice call
            
            phone = self.get_phone_number(recipient)
            if not phone:
                return f"Could not find phone number for {recipient}. Please add the contact first."
            
            # Open appropriate WhatsApp Web URL
            if call_type.lower() == "video":
                url = f"https://web.whatsapp.com/call/video/{phone}"
            else:
                url = f"https://web.whatsapp.com/call/voice/{phone}"
                
            webbrowser.open(url)
            time.sleep(5)  # Wait for WhatsApp Web to load
            
            # Handle call button click
            pyautogui.click(x=500, y=500)  # Approximate position of call button
            
            return f"Initiating {call_type} call with {recipient}..."
            
        except Exception as e:
            return f"Error making call: {str(e)}"

    def create_group(self, query):
        """Create WhatsApp group"""
        try:
            # Extract group name and members
            match = re.search(r"create\s+group\s+(?:named\s+)?([a-zA-Z\s]+)\s+with\s+(.+)", query, re.IGNORECASE)
            if not match:
                return "Could not understand the group creation format. Please try again."
            
            group_name, members = match.groups()
            member_list = [m.strip() for m in members.split(',')]
            
            # Open WhatsApp Web
            webbrowser.open("https://web.whatsapp.com")
            time.sleep(5)  # Wait for load
            
            # Click new group button (you'll need to adjust coordinates)
            pyautogui.click(x=200, y=200)
            time.sleep(1)
            
            # Type group name
            pyautogui.write(group_name)
            pyautogui.press('enter')
            
            # Add members
            for member in member_list:
                phone = self.get_phone_number(member)
                if phone:
                    pyautogui.write(phone)
                    pyautogui.press('enter')
                    time.sleep(0.5)
            
            return f"Created WhatsApp group '{group_name}' with {len(member_list)} members"
            
        except Exception as e:
            return f"Error creating group: {str(e)}"

    def handle_command(self, query):
        """Main handler for WhatsApp commands"""
        query = query.lower()
        
        try:
            # List contacts
            if "list contacts" in query:
                match = re.search(r"list\s+contacts(?:\s+in\s+group\s+([a-zA-Z\s]+))?", query)
                group = match.group(1) if match else None
                contacts = self.contacts.list_contacts(group)
                
                if not contacts:
                    return "No contacts found." if not group else f"No contacts found in group '{group}'."
                
                # Organize contacts by group
                grouped_contacts = {}
                for k, v in contacts.items():
                    for g in v.get('groups', ['No Group']):
                        if g not in grouped_contacts:
                            grouped_contacts[g] = []
                        grouped_contacts[g].append(f"📱 {v['name']}: {v['phone']}")
                
                # Format the output
                result = []
                for g, contacts in grouped_contacts.items():
                    result.append(f"\n👥 {g.upper()}:")
                    result.extend(contacts)
                
                return "\n".join(result)

            # Add/Update contact
            if any(phrase in query for phrase in ["add contact", "save number", "update contact"]):
                # Match more complex contact details
                match = re.search(
                    r"(?:add|save|update)\s+contact\s+([a-zA-Z\s]+)"
                    r"(?:\s+with\s+number\s+|\s+as\s+)(\+?\d+)"
                    r"(?:\s+email\s+([a-zA-Z0-9@._-]+))?"
                    r"(?:\s+group\s+([a-zA-Z,\s]+))?"
                    r"(?:\s+notes?\s+(.+))?", 
                    query, 
                    re.IGNORECASE
                )
                
                if match:
                    name, phone, email, groups, notes = match.groups()
                    groups = [g.strip() for g in (groups or "").split(",")] if groups else []
                    return self.contacts.add_contact(name, phone, email, groups, notes)
                return "Could not understand contact details. Please try again."
            
            # Delete contact
            if "delete contact" in query:
                match = re.search(r"delete\s+contact\s+([a-zA-Z\s]+)", query)
                if match:
                    name = match.group(1)
                    return self.contacts.delete_contact(name)
                return "Could not understand which contact to delete."

            # Send message
            if any(word in query for word in ["message", "send", "text", "msg"]):
                return self.send_message(query)
            
            # Make call
            if any(word in query for word in ["call", "dial", "phone"]):
                return self.make_call(query)
            
            # Create group
            if "create group" in query:
                return self.create_group(query)
            
            return "Unsupported WhatsApp command. Please try again."
            
        except Exception as e:
            return f"Error processing WhatsApp command: {str(e)}" 