import os
import json
import re
from datetime import datetime, timedelta
import threading
import time
from Backend.TextToSpeech import TextToSpeech
from dotenv import dotenv_values

env_vars = dotenv_values(".env")
Assistantname = env_vars.get("Assistantname")

class ReminderSystem:
    def __init__(self):
        self.reminder_file = os.path.join('Data', 'reminders.json')
        self.ensure_reminder_file()
        self.active_reminders = []
        
        # Advanced time patterns
        self.time_patterns = {
            'seconds': r'(?:in\s+)?(\d+)\s*(?:seconds?|secs?)',
            'minutes': r'(?:in\s+)?(\d+)\s*(?:minutes?|mins?)',
            'hours': r'(?:in\s+)?(\d+)\s*(?:hours?|hrs?)',
            'specific_time': r'(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*([ap]\.?m\.?)?',
            'relative': r'(?:in|after)\s+(\d+)\s*(seconds?|minutes?|hours?)',
            'natural': r'(this|next|tomorrow|tonight|evening|morning|afternoon)',
            'combined': r'(\d+)\s*(hours?|hrs?)\s+(?:and|&)?\s*(\d+)\s*(minutes?|mins?)'
        }

    def ensure_reminder_file(self):
        """Create reminders file if it doesn't exist"""
        os.makedirs('Data', exist_ok=True)
        if not os.path.exists(self.reminder_file):
            with open(self.reminder_file, 'w') as f:
                json.dump([], f)

    def parse_relative_time(self, time_str):
        """Parse relative time expressions"""
        now = datetime.now()
        
        if "morning" in time_str:
            return now.replace(hour=9, minute=0, second=0, microsecond=0)
        elif "afternoon" in time_str:
            return now.replace(hour=14, minute=0, second=0, microsecond=0)
        elif "evening" in time_str:
            return now.replace(hour=18, minute=0, second=0, microsecond=0)
        elif "tonight" in time_str:
            return now.replace(hour=20, minute=0, second=0, microsecond=0)
        elif "tomorrow" in time_str:
            return (now + timedelta(days=1)).replace(hour=9, minute=0, second=0, microsecond=0)
        
        return None

    def parse_duration(self, command):
        """Parse duration-based reminders"""
        total_seconds = 0
        
        # Check for combined format (e.g., "2 hours and 30 minutes")
        combined_match = re.search(self.time_patterns['combined'], command)
        if combined_match:
            hours = int(combined_match.group(1))
            minutes = int(combined_match.group(3))
            return timedelta(hours=hours, minutes=minutes).total_seconds()
        
        # Check for individual units
        for unit, pattern in [
            ('seconds', self.time_patterns['seconds']),
            ('minutes', self.time_patterns['minutes']),
            ('hours', self.time_patterns['hours'])
        ]:
            if match := re.search(pattern, command):
                value = int(match.group(1))
                if unit == 'seconds':
                    total_seconds += value
                elif unit == 'minutes':
                    total_seconds += value * 60
                elif unit == 'hours':
                    total_seconds += value * 3600
        
        return total_seconds if total_seconds > 0 else None

    def parse_time(self, command):
        """Enhanced time parsing"""
        try:
            # First check for duration-based reminders
            if duration_seconds := self.parse_duration(command.lower()):
                return datetime.now() + timedelta(seconds=duration_seconds)
            
            # Check for relative time expressions
            for pattern in ['morning', 'afternoon', 'evening', 'tonight', 'tomorrow']:
                if pattern in command.lower():
                    if reminder_time := self.parse_relative_time(command.lower()):
                        return reminder_time
            
            # Try parsing specific time formats
            time_formats = [
                "%I:%M %p",  # 3:30 PM
                "%I %p",     # 3 PM
                "%H:%M",     # 15:30
                "%H"         # 15
            ]
            
            # Extract time from command
            time_match = re.search(r'(\d{1,2}(?::\d{2})?(?:\s*[AaPp][Mm])?)', command)
            if time_match:
                time_str = time_match.group(1)
                
                for fmt in time_formats:
                    try:
                        parsed_time = datetime.strptime(time_str.strip().upper(), fmt)
                        now = datetime.now()
                        reminder_time = now.replace(
                            hour=parsed_time.hour,
                            minute=parsed_time.minute,
                            second=0,
                            microsecond=0
                        )
                        
                        # If the time has already passed today, set it for tomorrow
                        if reminder_time < now:
                            reminder_time += timedelta(days=1)
                        
                        return reminder_time
                    except ValueError:
                        continue
            
            return None
        except Exception:
            return None

    def save_reminder(self, task, reminder_time):
        """Save reminder with priority and recurrence"""
        try:
            with open(self.reminder_file, 'r') as f:
                reminders = json.load(f)
            
            # Check for priority keywords
            priority = 'normal'
            if any(word in task.lower() for word in ['urgent', 'important', 'asap', 'emergency']):
                priority = 'high'
            
            reminder = {
                'task': task,
                'time': reminder_time.strftime('%Y-%m-%d %H:%M:%S'),
                'status': 'active',
                'priority': priority,
                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            reminders.append(reminder)
            
            with open(self.reminder_file, 'w') as f:
                json.dump(reminders, f, indent=4)
                
            # Start reminder thread
            self.start_reminder(reminder)
            
            return True
        except Exception as e:
            print(f"Error saving reminder: {str(e)}")
            return False

    def start_reminder(self, reminder):
        """Enhanced reminder notification"""
        def reminder_thread():
            reminder_time = datetime.strptime(reminder['time'], '%Y-%m-%d %H:%M:%S')
            delay = (reminder_time - datetime.now()).total_seconds()
            
            if delay > 0:
                time.sleep(delay)
                
                # Format notification based on priority
                if reminder['priority'] == 'high':
                    notification = f"⚠️ URGENT REMINDER: {reminder['task']}!"
                else:
                    notification = f"🔔 Reminder: {reminder['task']}"
                
                from Frontend.GUI import ShowTextToScreen
                ShowTextToScreen(f"{Assistantname}: {notification}")
                TextToSpeech(notification.replace('⚠️', '').replace('🔔', ''))
                
                # Optional: Add snooze functionality here

        thread = threading.Thread(target=reminder_thread, daemon=True)
        thread.start()
        self.active_reminders.append(thread)

# Create global instance
reminder_system = ReminderSystem()

def handle_reminder_command(command: str) -> dict:
    """Enhanced reminder command handling"""
    try:
        # First try to extract duration for quick reminders
        quick_patterns = [
            r'(?:in|after)\s+(\d+)\s*(seconds?|minutes?|hours?)\s+(?:to|about|that)\s+(.+)',
            r'(?:remind\s+(?:me\s+)?)?(?:in|after)\s+(\d+)\s*(seconds?|minutes?|hours?)\s+(?:to|about|that)?\s*(.+)',
        ]

        for pattern in quick_patterns:
            if match := re.search(pattern, command, re.IGNORECASE):
                number = int(match.group(1))
                unit = match.group(2).lower().rstrip('s')  # remove potential 's' from unit
                task = match.group(3).strip()

                # Calculate seconds
                if unit == 'second':
                    total_seconds = number
                elif unit == 'minute':
                    total_seconds = number * 60
                elif unit == 'hour':
                    total_seconds = number * 3600

                # Set reminder
                reminder_time = datetime.now() + timedelta(seconds=total_seconds)
                if reminder_system.save_reminder(task, reminder_time):
                    return {
                        'time': f"{number} {unit}{'s' if number > 1 else ''}",
                        'task': task
                    }

        # If not a quick reminder, try other patterns
        task_patterns = [
            r'(?:remind\s+(?:me\s+)?(?:to|about|that)\s+)(.+?)(?:\s+(?:in|at|after|tomorrow|tonight|evening|morning|afternoon))',
            r'(?:set\s+(?:a\s+)?reminder\s+(?:to|about|that)\s+)(.+?)(?:\s+(?:in|at|after|tomorrow|tonight|evening|morning|afternoon))',
            r'(?:tomorrow|tonight|evening|morning|afternoon)\s+(?:to|about|that)\s+(.+)'
        ]
        
        task = None
        for pattern in task_patterns:
            if match := re.search(pattern, command, re.IGNORECASE | re.DOTALL):
                task = match.group(1).strip()
                break
        
        if not task:
            # Try to extract task from the end of the command
            task = command.split()[-3:]  # Take last 3 words as task
            task = ' '.join(task)
        
        # Parse time
        reminder_time = reminder_system.parse_time(command)
        if not reminder_time:
            return None
        
        # Save reminder
        if not reminder_system.save_reminder(task, reminder_time):
            return None
        
        # Calculate display time
        now = datetime.now()
        delta = reminder_time - now
        
        if delta.days > 0:
            time_str = reminder_time.strftime('%I:%M %p tomorrow')
        elif delta.seconds >= 3600:
            hours = delta.seconds // 3600
            minutes = (delta.seconds % 3600) // 60
            time_str = f"{hours}h {minutes}m from now"
        elif delta.seconds >= 60:
            minutes = delta.seconds // 60
            time_str = f"{minutes} minutes from now"
        else:
            time_str = f"{delta.seconds} seconds from now"
        
        return {
            'time': time_str,
            'task': task
        }
        
    except Exception as e:
        print(f"Error processing reminder: {str(e)}")
        return None
