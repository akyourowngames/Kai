import requests
import geocoder
import socket
import platform
import webbrowser
from geopy.geocoders import Nominatim
import folium
from timezonefinder import TimezoneFinder
from datetime import datetime
import pytz
import json
import os
from dotenv import dotenv_values
import warnings
warnings.filterwarnings('ignore')

class LocationSystem:
    def __init__(self):
        self.env_vars = dotenv_values(".env")
        self.google_api_key = self.env_vars.get("GoogleMapsAPIKey")
        self.geolocator = Nominatim(user_agent="my_assistant")
        self.tf = TimezoneFinder()
        self.location_cache_file = "Data/location_cache.json"
        self.initialize_cache()

    def initialize_cache(self):
        """Initialize the location cache file"""
        os.makedirs('Data', exist_ok=True)
        if not os.path.exists(self.location_cache_file):
            with open(self.location_cache_file, 'w') as f:
                json.dump({}, f)

    def get_location(self, method="all"):
        """Get location using multiple methods"""
        try:
            methods = {
                "browser": self._get_browser_location,
                "ip": self._get_ip_location,
                "wifi": self._get_wifi_location,
                "gps": self._get_gps_location,
                "all": self._get_best_location
            }
            
            if method in methods:
                location = methods[method]()
                if location:
                    self._cache_location(location)
                    return self._format_location(location)
            return "Could not determine location accurately."
            
        except Exception as e:
            print(f"Error getting location: {str(e)}")
            return "Error determining location."

    def _get_browser_location(self):
        """Get location using browser geolocation"""
        try:
            # Create a simple HTML file with geolocation request
            html_content = """
            <html>
            <body>
            <script>
            function getLocation() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(showPosition);
                }
            }
            function showPosition(position) {
                document.write(position.coords.latitude + "," + position.coords.longitude);
            }
            getLocation();
            </script>
            </body>
            </html>
            """
            
            # Save and open in browser
            with open("temp_location.html", "w") as f:
                f.write(html_content)
            webbrowser.open("temp_location.html")
            
            return self._get_cached_location()
            
        except Exception as e:
            print(f"Browser location error: {str(e)}")
            return None

    def _get_ip_location(self):
        """Get location using IP address"""
        try:
            g = geocoder.ip('me')
            if g.ok:
                return {
                    'latitude': g.lat,
                    'longitude': g.lng,
                    'address': g.address,
                    'city': g.city,
                    'state': g.state,
                    'country': g.country,
                    'method': 'ip'
                }
            return None
        except Exception as e:
            print(f"IP location error: {str(e)}")
            return None

    def _get_wifi_location(self):
        """Get location using nearby WiFi access points"""
        try:
            if platform.system() == 'Windows':
                import subprocess
                
                # Get WiFi networks info
                networks = subprocess.check_output(['netsh', 'wlan', 'show', 'networks', 'mode=Bssid']).decode('utf-8')
                
                # Extract BSSIDs (MAC addresses) and signal strengths
                wifi_data = []
                for line in networks.split('\n'):
                    if 'BSSID' in line or 'Signal' in line:
                        wifi_data.append(line.strip())
                
                # Use Google's Geolocation API
                url = f"https://www.googleapis.com/geolocation/v1/geolocate?key={self.google_api_key}"
                wifi_access_points = []
                
                for i in range(0, len(wifi_data), 2):
                    if i+1 < len(wifi_data):
                        bssid = wifi_data[i].split(': ')[1]
                        signal = int(wifi_data[i+1].split(': ')[1].replace('%', ''))
                        wifi_access_points.append({
                            "macAddress": bssid,
                            "signalStrength": signal
                        })
                
                if wifi_access_points:
                    response = requests.post(url, json={"wifiAccessPoints": wifi_access_points})
                    if response.status_code == 200:
                        result = response.json()
                        return {
                            'latitude': result['location']['lat'],
                            'longitude': result['location']['lng'],
                            'accuracy': result['accuracy'],
                            'method': 'wifi'
                        }
            return None
            
        except Exception as e:
            print(f"WiFi location error: {str(e)}")
            return None

    def _get_gps_location(self):
        """Get location using GPS (if available)"""
        try:
            # This is a placeholder for GPS implementation
            # You would need appropriate hardware/drivers for actual GPS
            return None
        except Exception as e:
            print(f"GPS location error: {str(e)}")
            return None

    def _get_best_location(self):
        """Try all methods and return the most accurate result"""
        locations = []
        
        # Try GPS first (most accurate)
        gps_location = self._get_gps_location()
        if gps_location:
            return gps_location
            
        # Try WiFi location
        wifi_location = self._get_wifi_location()
        if wifi_location:
            locations.append(wifi_location)
            
        # Try browser location
        browser_location = self._get_browser_location()
        if browser_location:
            locations.append(browser_location)
            
        # Try IP location (least accurate)
        ip_location = self._get_ip_location()
        if ip_location:
            locations.append(ip_location)
            
        # Return the most accurate location (based on method hierarchy)
        for method in ['gps', 'wifi', 'browser', 'ip']:
            for location in locations:
                if location['method'] == method:
                    return location
                    
        return None

    def _cache_location(self, location):
        """Cache the location data"""
        try:
            with open(self.location_cache_file, 'r') as f:
                cache = json.load(f)
            
            cache[datetime.now().strftime("%Y-%m-%d %H:%M:%S")] = location
            
            # Keep only last 24 hours of data
            cache = {k: v for k, v in cache.items() 
                    if (datetime.now() - datetime.strptime(k, "%Y-%m-%d %H:%M:%S")).days < 1}
            
            with open(self.location_cache_file, 'w') as f:
                json.dump(cache, f, indent=4)
                
        except Exception as e:
            print(f"Cache error: {str(e)}")

    def _get_cached_location(self):
        """Get the most recent cached location"""
        try:
            with open(self.location_cache_file, 'r') as f:
                cache = json.load(f)
            
            if cache:
                latest = max(cache.keys())
                return cache[latest]
            return None
            
        except Exception as e:
            print(f"Cache read error: {str(e)}")
            return None

    def _format_location(self, location):
        """Format location data into a readable message"""
        try:
            # Get detailed address using reverse geocoding
            geolocator = Nominatim(user_agent="my_assistant")
            location_detail = geolocator.reverse(f"{location['latitude']}, {location['longitude']}")
            
            # Get timezone and local time
            timezone_str = self.tf.timezone_at(lat=location['latitude'], lng=location['longitude'])
            timezone = pytz.timezone(timezone_str)
            local_time = datetime.now(timezone).strftime("%I:%M %p")
            
            # Create and save map
            map_file = "Data/location_map.html"
            m = folium.Map(location=[location['latitude'], location['longitude']], zoom_start=15)
            folium.Marker(
                [location['latitude'], location['longitude']],
                popup="Your Location",
                icon=folium.Icon(color='red', icon='info-sign')
            ).add_to(m)
            m.save(map_file)
            
            # Format message
            message = "📍 Your Current Location:\n\n"
            message += f"📌 Address: {location_detail.address}\n"
            message += f"🌍 Coordinates: {location['latitude']:.6f}, {location['longitude']:.6f}\n"
            message += f"🏙️ City: {location.get('city', location_detail.raw.get('address', {}).get('city', 'Unknown'))}\n"
            message += f"🗺️ State: {location.get('state', location_detail.raw.get('address', {}).get('state', 'Unknown'))}\n"
            message += f"🌐 Country: {location.get('country', location_detail.raw.get('address', {}).get('country', 'Unknown'))}\n"
            message += f"⏰ Local Time: {local_time}\n"
            message += f"🌐 Timezone: {timezone_str}\n"
            
            if 'accuracy' in location:
                message += f"📏 Accuracy: within {location['accuracy']} meters\n"
                
            message += f"\n🗺️ Map has been saved to: {os.path.abspath(map_file)}"
            
            return message
            
        except Exception as e:
            print(f"Format error: {str(e)}")
            return str(location)

    def get_nearby_places(self, place_type="all", radius=1000):
        """Get nearby places of interest"""
        try:
            location = self._get_best_location()
            if not location:
                return "Could not determine location."
                
            url = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
            
            params = {
                "location": f"{location['latitude']},{location['longitude']}",
                "radius": radius,
                "key": self.google_api_key
            }
            
            if place_type != "all":
                params["type"] = place_type
                
            response = requests.get(url, params=params)
            places = response.json()
            
            if places.get("status") == "OK":
                message = "🏢 Nearby Places:\n\n"
                for place in places["results"][:10]:  # Show top 10 results
                    message += f"📍 {place['name']}\n"
                    message += f"   Type: {', '.join(place['types'])}\n"
                    message += f"   Rating: {'⭐' * int(place.get('rating', 0))} ({place.get('rating', 'N/A')})\n"
                    message += f"   Address: {place.get('vicinity', 'N/A')}\n\n"
                return message
            return "No places found nearby."
            
        except Exception as e:
            print(f"Nearby places error: {str(e)}")
            return "Error finding nearby places." 