import pygame
import random
import asyncio
import edge_tts
import os
from dotenv import dotenv_values

# Load environment variables
env_vars = dotenv_values(".env")
AssistantVoice = env_vars.get("AssistantVoice", "en-US")

async def TextToAudioFile(text: str) -> None:
    """
    Converts the given text to an audio file using edge_tts and saves it as 'speech.mp3'.
    """
    file_path = os.path.join("Data", "speech.mp3")

    # Remove existing file if it exists
    if os.path.exists(file_path):
        os.remove(file_path)

    communicate = edge_tts.Communicate(
        text, 
        AssistantVoice,
        rate="+13%",
        pitch="+5Hz"
    )
    await communicate.save(file_path)

def TTS(Text: str, func=lambda r=None: True) -> bool:
    """
    Text-to-Speech functionality using pygame for playback.
    """
    try:
        # Generate audio file
        asyncio.run(TextToAudioFile(Text))

        # Initialize pygame mixer
        pygame.mixer.init()
        file_path = os.path.join("Data", "speech.mp3")
        pygame.mixer.music.load(file_path)
        pygame.mixer.music.play()

        # Play audio while monitoring function
        while pygame.mixer.music.get_busy():
            if func() is False:
                break
            pygame.time.Clock().tick(10)

        return True

    except Exception as e:
        print(f"Error in TTS: {e}")
        return False

    finally:
        try:
            func(False)
            pygame.mixer.music.stop()
            pygame.mixer.quit()
        except Exception as e:
            print(f"Error in finally block: {e}")

def TextToSpeech(Text: str, func=lambda r=None: True):
    """
    Handles text-to-speech with long text handling
    """
    sentences = Text.split(".")
    
    # Predefined responses
    responses = [
        "The rest of the result has been printed to the chat screen, kindly check it out sir.",
        "The rest of the text is now on the chat screen, sir, please check it.",
        "You can see the rest of the text on the chat screen, sir.",
        "The remaining part of the text is now on the chat screen, sir.",
        "Sir, you'll find more text on the chat screen for you to see."
    ]

    # Check if the text is long
    if len(sentences) > 4 and len(Text) >= 250:
        TTS(" ".join(sentences[:2]) + ". " + random.choice(responses), func)
    else:
        TTS(Text, func)

if __name__ == "__main__":
    os.makedirs("Data", exist_ok=True)  # Ensure Data directory exists

    while True:
        user_input = input("Enter the text: ")
        TextToSpeech(user_input)
