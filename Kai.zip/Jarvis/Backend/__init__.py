from Backend.Basic import ChromeCode
from Backend.reminder_system import handle_reminder_command

KnownApps = {"Google Chrome": ChromeCode}

# This file can be empty - it just marks the directory as a Python package