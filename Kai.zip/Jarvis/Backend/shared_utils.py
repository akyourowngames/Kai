# Shared utilities to break circular dependencies
from typing import Optional, Callable
import os

# Global variables
_text_display_callback = None
_tts_callback = None
_assistant_name = None
_username = None

# Temp directory path helper
def get_temp_dir_path(filename: str) -> str:
    current_dir = os.getcwd()
    temp_dir_path = os.path.join(current_dir, "Frontend", "Files")
    return os.path.join(temp_dir_path, filename)

# Status management functions
def set_microphone_status(command: str) -> None:
    with open(get_temp_dir_path("Mic.data"), "w", encoding='utf-8') as file:
        file.write(command)

def get_microphone_status() -> str:
    with open(get_temp_dir_path("Mic.data"), "r", encoding='utf-8') as file:
        return file.read()

def set_assistant_status(status: str) -> None:
    with open(get_temp_dir_path("Status.data"), "w", encoding='utf-8') as file:
        file.write(status)

def get_assistant_status() -> str:
    with open(get_temp_dir_path("Status.data"), "r", encoding='utf-8') as file:
        return file.read()

# Text display and speech functions
def show_text(text: str) -> None:
    """Display text using registered callback"""
    if _text_display_callback:
        _text_display_callback(text)
    else:
        print(text)  # Fallback to console

def speak_text(text: str) -> None:
    """Speak text using registered callback"""
    if _tts_callback:
        _tts_callback(text)
    else:
        print(f"[SPEAK]: {text}")  # Fallback to console

# Registration functions
def register_display_callback(callback: Callable[[str], None]) -> None:
    """Register the function to display text on screen"""
    global _text_display_callback
    _text_display_callback = callback

def register_tts_callback(callback: Callable[[str], None]) -> None:
    """Register the text-to-speech function"""
    global _tts_callback
    _tts_callback = callback

def register_names(assistant_name: str, username: str) -> None:
    global _assistant_name, _username
    _assistant_name = assistant_name
    _username = username

def get_assistant_name() -> str:
    return _assistant_name

def get_username() -> str:
    return _username 