from Backend.Model import FirstLayerDMM
from Backend.RealtimeSearchEngine import RealtimeSearchEngine
from Backend.Automation import Automation
from Backend.SpeechToText import SpeechRecognition
from Backend.Chatbot import ChatBot 
from Backend.TextToSpeech import TextToSpeech
from Backend.helpers import (
    SetAssistantStatus,
    ShowTextToScreen,
    QueryModifier,
    TempDirectoryPath,
    Assistantname,
    Username
)
from asyncio import run
import subprocess
import os

def TypeQuery(query):
    TaskExecution = False 
    ImageExecution = False
    ImageGenerationQuery = ""
    subprocesses = []
    
    SetAssistantStatus("Thinking ...")
    Decision = FirstLayerDMM(query)
    
    print(f"\nDecision : {Decision}\n")

    G = any([i for i in Decision if i.startswith("general")])
    R = any([i for i in Decision if i.startswith("realtime")])

    Mearged_query = " and ".join(
        [" ".join(i.split()[1:]) for i in Decision if i.startswith("general") or i.startswith("realtime")]
    )
    
    for queries in Decision:
        if "generate " in queries:
            ImageGenerationQuery = str(queries)
            ImageExecution = True

    for queries in Decision:
        if TaskExecution == False:
            if any(queries.startswith(func) for func in ["open", "close", "play", "system", "content", "google search", "youtube search"]):
                run(Automation(list(Decision)))           
                TaskExecution = True
                
    if ImageExecution == True:
        with open(r"Frontend/Files/ImageGeneration.data", "w") as file:
            file.write(f"{ImageGenerationQuery}, True")
        print(f"Written to ImageGeneration.data: {ImageGenerationQuery}, True")
        
        try:
            p1 = subprocess.Popen(['python', r'Backend/ImageGeneration.py'],
                                  stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                  stdin=subprocess.PIPE, shell=True)
            subprocesses.append(p1)
            print("Started ImageGeneration.py subprocess")
        except FileNotFoundError:
            print("Error starting ImageGeneration.py: FileNotFoundError")      
        except Exception as e:
            print(f"Error starting ImageGeneration.py: {e}")   
            
    if G and R or R:
        try:
            SetAssistantStatus("Searching...")
            Answer = RealtimeSearchEngine(QueryModifier(Mearged_query))
            ShowTextToScreen(f"{Assistantname} : {Answer}")
            SetAssistantStatus("Answering...")
            TextToSpeech(Answer)
            return True
        except Exception as e:
            print(f"Error during real-time search: {e}")
            SetAssistantStatus("Error during real-time search")
            return False

    else:
        for Queries in Decision:
            if "general" in Queries:
                try:
                    SetAssistantStatus("Thinking...")
                    QueryFinal = Queries.replace("general ", "")
                    Answer = ChatBot(QueryModifier(QueryFinal))
                    ShowTextToScreen(f"{Assistantname} : {Answer}")
                    SetAssistantStatus("Answering...")
                    TextToSpeech(Answer)
                    return True
                except Exception as e:
                    print(f"Error during general query processing: {e}")
                    SetAssistantStatus("Error during general query processing")
                    return False
                
            elif "realtime" in Queries:
                try:
                    SetAssistantStatus("Searching...")
                    QueryFinal = Queries.replace("realtime ", "")
                    Answer = RealtimeSearchEngine(QueryModifier(QueryFinal))
                    ShowTextToScreen(f"{Assistantname} : {Answer}")
                    SetAssistantStatus("Answering...")
                    TextToSpeech(Answer)
                    return True
                except Exception as e:
                    print(f"Error during real-time query processing: {e}")
                    SetAssistantStatus("Error during real-time query processing")
                    return False
                
            elif "exit" in Queries:
                QueryFinal = "Okay , Bye!"
                Answer = ChatBot(QueryModifier(QueryFinal))
                ShowTextToScreen(f"{Assistantname} : {Answer}")
                SetAssistantStatus("Answering...")
                TextToSpeech(Answer)
                SetAssistantStatus("Answering...")
                os._exit(1)

            elif "send email" in Queries:
                try:
                    SetAssistantStatus("Sending email...")
                    response = Queries.replace("send email ", "")
                    ShowTextToScreen(f"{Assistantname} : {response}")
                    SetAssistantStatus("Email sent...")
                    TextToSpeech(response)
                    return True
                except Exception as e:
                    print(f"Error sending email: {e}")
                    SetAssistantStatus("Error sending email")
                    return False
