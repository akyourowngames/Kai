ChromeList = {
    "Ctrl + n": ["open", "new", "window"],

    "Ctrl + Shift + n": ["open", "new", "incognito", "window"],

    "Ctrl + t": ["open", "new", "tab"],

    "Ctrl + Shift + t": [
        ["Reopen", "open", "go to"],
        ["previously", "previous"],
        ["tab", "tabs"],
    ],

    "Ctrl + w": ["close", "current", "tab"],

    "Ctrl + Shift + w": ["close", "all", "tabs", "window"],

    "Ctrl + Tab": ["switch", "move", "next", "tab"],

    "Ctrl + Shift + Tab": ["switch", "move", "previous", "tab"],

    "Ctrl + l": ["focus", "address", "bar", "omnibox"],

    "Ctrl + e": ["search", "omnibox", "address", "bar"],

    "Ctrl + k": ["search", "omnibox", "address", "bar"],

    "Ctrl + d": ["bookmark", "save", "current", "page"],

    "Ctrl + Shift + d": ["bookmark", "save", "all", "tabs"],

    "Ctrl + h": ["open", "history", "view", "browsing"],

    "Ctrl + j": ["open", "downloads", "view", "files"],

    "Ctrl + p": ["print", "current", "page", "document"],

    "Ctrl + s": ["save", "current", "page", "document"],

    "Ctrl + r": ["reload", "refresh", "page"],

    "Ctrl + Shift + r": ["reload", "refresh", "page", "force", "cache"],

    "Ctrl + u": ["view", "page", "source", "html"],

    "Ctrl + Shift + i": ["open", "developer", "tools", "inspect"],

    "Ctrl + f": ["find", "search", "current", "page"],

    "Ctrl + g": ["find", "next", "search", "current", "page"],

    "Ctrl + Shift + g": ["find", "previous", "search", "current", "page"],

    "Ctrl + +": ["zoom", "in", "increase", "size"],

    "Ctrl + -": ["zoom", "out", "decrease", "size"],

    "Ctrl + 0": ["reset", "zoom", "default", "size"],

    "F11": ["toggle", "fullscreen", "mode"],

    "Ctrl + Shift + b": ["show", "hide", "bookmarks", "bar"],

    "Ctrl + Shift + o": ["open", "bookmark", "manager"],

    "Ctrl + Shift + j": ["open", "javascript", "console"],

    "Ctrl + Shift + Delete": ["clear", "browsing", "data", "history", "cache"],

    "Alt + Left Arrow": ["go", "back", "previous", "page"],

    "Alt + Right Arrow": ["go", "forward", "next", "page"],

    "Ctrl + q": ["quit", "exit", "close", "browser"],

    "Ctrl + Shift + q": ["quit", "exit", "close", "browser", "force"]
}
