from groq import Groq
from json import load, dump
import datetime
import time
import requests
from dotenv import dotenv_values
from flask import Flask, request, jsonify
from flask_cors import CORS
from bs4 import BeautifulSoup

env_vars = dotenv_values(".env")

Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = "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"
client = Groq(api_key=GroqAPIKey)

System = f"""Hello, I am {Username}, You are a very accurate and advanced AI chatbot named {Assistantname} which has real-time up-to-date information from the internet.
*** Provide Answers In a Professional Way, make sure to add full stops, commas, question marks, and use proper grammar.***
*** Just answer the question from the provided data in a professional way. ***"""

try:
    with open(r"C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json", "r") as f:
        messages = load(f)
except:
    with open(r"C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json", "w") as f:
        dump([], f)

def GoogleSearch(query):
    if not query.strip():
        return "The query is empty. Please provide a valid query."

    api_key = "AIzaSyC74v06ltdQq0pfFCzJUtBNbEpxV-WDvtI"
    cx = "5499c886f72f9477b"  # Your Custom Search Engine ID
    search_url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": api_key,
        "cx": cx,
        "q": query,
        "num": 5
    }

    response = requests.get(search_url, params=params)
    response.raise_for_status()
    search_results = response.json()

    Answer = f"The search results for '{query}' are:\n[start]\n"
    for item in search_results.get("items", []):
        Answer += f"Title: {item['title']}\nURL: {item['link']}\nDescription: {item['snippet']}\n\n"
    Answer += "[end]"
    return Answer

def AnswerModifier(Answer):
    """Enhanced answer modifier for better formatting"""
    try:
        # Remove multiple newlines and spaces
        lines = Answer.split('\n')
        non_empty_lines = [line.strip() for line in lines if line.strip()]
        
        # Remove redundant spaces
        cleaned_lines = [' '.join(line.split()) for line in non_empty_lines]
        
        # Join with proper spacing
        modified_answer = '\n'.join(cleaned_lines)
        
        # Ensure proper punctuation
        if modified_answer and not modified_answer.endswith(('.', '!', '?')):
            modified_answer += '.'
            
        return modified_answer
        
    except Exception as e:
        print(f"Error in AnswerModifier: {str(e)}")
        return Answer  # Return original answer if modification fails

def Information():
    data = ""
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")
    data = f"Use this Real-Time Information if needed,\n"
    data += f"Day: {day}\n"
    data += f"Date: {date}\n"
    data += f"Month: {month}\n"
    data += f"Year: {year}\n"
    data += f"Time: {hour} hours, {minute} minutes, {second} seconds.\n"
    return data

SystemChatBot = [
    {"role": "system", "content": System},
    {"role": "user", "content": "Hi"},
    {"role": "assistant", "content": "Hello, how can I help you?"}
]

def RealtimeSearchEngine(prompt):
    """Enhanced realtime search engine with better answer processing"""
    try:
        # Get search results
        search_result = GoogleSearch(prompt)
        if search_result == "The query is empty. Please provide a valid query.":
            return search_result
        
        # Process search results to extract relevant information
        if "[start]" in search_result and "[end]" in search_result:
            start_idx = search_result.find("[start]") + 7
            end_idx = search_result.find("[end]")
            search_content = search_result[start_idx:end_idx].strip()
            
            # Extract and process snippets
            relevant_info = ""
            snippets = search_content.split("\n\n")
            for snippet in snippets:
                if "Description:" in snippet:
                    description = snippet.split("Description:")[1].strip()
                    if len(description) > 30:  # Only use meaningful descriptions
                        relevant_info += description + "\n"
            
            if relevant_info:
                # Create a focused prompt for the LLM
                focused_prompt = f"""Based on the following information, provide a clear and professional answer to the question: "{prompt}"

                Information from search results:
                {relevant_info}

                Please provide a direct, factual answer using this information. Focus on accuracy and clarity."""
                
                # Get response from LLM
                completion = client.chat.completions.create(
                    model="llama3-70b-8192",
                    messages=[
                        {"role": "system", "content": System},
                        {"role": "user", "content": focused_prompt}
                    ],
                    temperature=0.3,  # Lower temperature for more focused responses
                    max_tokens=1024,
                    top_p=1,
                    stream=False,
                    stop=None
                )
                
                Answer = completion.choices[0].message.content
                Answer = Answer.strip().replace("</s>", "")
                
                # Clean up the answer
                Answer = Answer.replace('\n\n', '\n').strip()
                Answer = ' '.join(Answer.split())  # Remove extra spaces
                
                return AnswerModifier(Answer=Answer)
        
        return "I apologize, but I couldn't find specific information to answer your question accurately."
        
    except Exception as e:
        print(f"Error in RealtimeSearchEngine: {str(e)}")
        return "I encountered an error while searching for that information. Please try again."

app = Flask(__name__)
CORS(app)

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    prompt = data.get('prompt', '')
    if not prompt:
        return jsonify({'response': 'The query is empty. Please provide a valid query.'})
    
    response = RealtimeSearchEngine(prompt)
    return jsonify({'response': response})

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)