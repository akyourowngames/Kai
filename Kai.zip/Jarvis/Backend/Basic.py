from Backend.Chrome import ChromeList
import keyboard
import pygetwindow as gw
import time
import webbrowser
import re
import pyautogui
from urllib.parse import quote
import os
import subprocess
import winreg
from dotenv import load_dotenv

class ChromeAutomation:
    def __init__(self):
        load_dotenv()
        self.chrome_path = self.get_chrome_path()
        self.last_active_window = None
        
        # Advanced command mappings with variations
        self.command_mappings = {
            # Navigation Commands
            "go back": ["back", "previous page", "return", "last page"],
            "go forward": ["forward", "next page", "advance"],
            "refresh": ["reload", "update", "refresh page", "reload page"],
            "hard refresh": ["force reload", "clear cache and reload", "complete refresh"],
            
            # Tab Management
            "new tab": ["open tab", "create tab", "start tab", "launch tab"],
            "close tab": ["exit tab", "remove tab", "end tab", "kill tab"],
            "switch tab": ["change tab", "next tab", "move tab", "cycle tab"],
            "previous tab": ["last tab", "prior tab", "go back tab"],
            "duplicate tab": ["copy tab", "clone tab", "replicate tab"],
            "restore tab": ["reopen tab", "recover tab", "bring back tab", "undo close"],
            "pin tab": ["stick tab", "keep tab", "lock tab"],
            "mute tab": ["silence tab", "quiet tab", "disable sound"],
            
            # Window Management
            "new window": ["open window", "create window", "start window"],
            "close window": ["exit window", "quit chrome", "terminate window"],
            "minimize": ["minimize window", "hide window", "shrink window"],
            "maximize": ["maximize window", "full window", "enlarge window"],
            "split left": ["dock left", "move left", "position left"],
            "split right": ["dock right", "move right", "position right"],
            
            # Features
            "history": ["show history", "open history", "view history", "browse history"],
            "downloads": ["show downloads", "open downloads", "view downloads", "get downloads"],
            "bookmarks": ["show bookmarks", "open bookmarks", "view bookmarks"],
            "extensions": ["show extensions", "manage extensions", "view extensions"],
            "settings": ["show settings", "open settings", "chrome settings"],
            
            # Tools
            "developer tools": ["dev tools", "inspect", "developer console", "debug tools"],
            "task manager": ["chrome tasks", "browser tasks", "process manager"],
            "clear data": ["clear history", "clear cache", "clean browser"],
            
            # View Controls
            "zoom in": ["increase size", "make bigger", "larger", "zoom up"],
            "zoom out": ["decrease size", "make smaller", "smaller", "zoom down"],
            "reset zoom": ["normal zoom", "default zoom", "restore zoom"],
            "full screen": ["enter fullscreen", "maximize view", "theater mode"],
            
            # Search and Find
            "find": ["search page", "find text", "locate on page", "search in page"],
            "search": ["google", "look up", "search for", "find online"],
            
            # Special Features
            "incognito": ["private window", "private browsing", "incognito mode"],
            "reader mode": ["reading view", "simplified view", "reader view"],
            "print": ["print page", "create pdf", "save as pdf"],
            "source": ["view source", "page source", "show source"],
            
            # Add new scroll and navigation commands
            "scroll down": ["page down", "move down", "go down", "scroll further"],
            "scroll up": ["page up", "move up", "go up", "scroll back"],
            "scroll to top": ["go to top", "back to top", "start of page"],
            "scroll to bottom": ["go to bottom", "end of page", "bottom of page"],
            "smooth scroll": ["scroll slowly", "gentle scroll", "smooth move"],
            
            # Enhanced Navigation
            "back to top": ["return to top", "jump to top", "start"],
            "go to bottom": ["jump to bottom", "end", "finish"],
            "scroll half": ["scroll middle", "move halfway", "center page"],
            
            # Smart Scrolling
            "scroll section": ["next section", "move section", "jump section"],
            "previous section": ["last section", "prior section", "back section"],
            
            # Reading Mode
            "read mode": ["reading mode", "article mode", "clean view"],
            "focus mode": ["concentrate mode", "distraction free", "zen mode"],
            
            # Enhanced Tab Management
            "first tab": ["go to first tab", "switch to first", "start tab"],
            "last tab": ["go to last tab", "switch to last", "end tab"],
            "tab left": ["move tab left", "shift tab left", "reorder left"],
            "tab right": ["move tab right", "shift tab right", "reorder right"],
            
            # Window Management
            "split screen": ["split view", "side by side", "split window"],
            "stack windows": ["cascade windows", "arrange windows", "tile windows"],
            "minimize others": ["hide others", "focus this", "only this"],
        }
        
        # Keyboard shortcuts for each command
        self.shortcuts = {
            "go back": "alt+left",
            "go forward": "alt+right",
            "refresh": "f5",
            "hard refresh": "ctrl+f5",
            "new tab": "ctrl+t",
            "close tab": "ctrl+w",
            "switch tab": "ctrl+tab",
            "previous tab": "ctrl+shift+tab",
            "duplicate tab": "alt+d,ctrl+c,ctrl+t,ctrl+v,enter",
            "restore tab": "ctrl+shift+t",
            "pin tab": "alt+p",
            "mute tab": "alt+m",
            "new window": "ctrl+n",
            "close window": "alt+f4",
            "minimize": "windows+down",
            "maximize": "windows+up",
            "split left": "windows+left",
            "split right": "windows+right",
            "history": "ctrl+h",
            "downloads": "ctrl+j",
            "bookmarks": "ctrl+b",
            "extensions": "ctrl+shift+e",
            "settings": "alt+f,s",
            "developer tools": "f12",
            "task manager": "shift+esc",
            "clear data": "ctrl+shift+delete",
            "zoom in": "ctrl+plus",
            "zoom out": "ctrl+minus",
            "reset zoom": "ctrl+0",
            "full screen": "f11",
            "find": "ctrl+f",
            "incognito": "ctrl+shift+n",
            "print": "ctrl+p",
            "source": "ctrl+u",
            "scroll down": "pagedown",
            "scroll up": "pageup",
            "scroll to top": "home",
            "scroll to bottom": "end",
            "smooth scroll": "space",
            "back to top": "home",
            "go to bottom": "end",
            "scroll half": "pagedown,pagedown",
            "scroll section": "pagedown",
            "previous section": "pageup",
            "read mode": "ctrl+alt+r",
            "focus mode": "f11",
            "first tab": "ctrl+1",
            "last tab": "ctrl+9",
            "tab left": "ctrl+shift+pageup",
            "tab right": "ctrl+shift+pagedown",
            "split screen": "windows+left",
            "stack windows": "windows+up",
            "minimize others": "windows+home"
        }

    def get_chrome_path(self):
        """Get Chrome installation path from Windows Registry"""
        try:
            # Try to get path from registry
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe")
            chrome_path = winreg.QueryValue(key, None)
            winreg.CloseKey(key)
            return chrome_path
        except:
            # Fallback to common installation paths
            common_paths = [
                os.path.expandvars(r"%ProgramFiles%\Google\Chrome\Application\chrome.exe"),
                os.path.expandvars(r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"),
                os.path.expandvars(r"%LocalAppData%\Google\Chrome\Application\chrome.exe"),
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
            ]
            
            for path in common_paths:
                if os.path.exists(path):
                    return path
            return None

    def launch_chrome(self):
        """Launch Chrome browser"""
        try:
            if self.chrome_path and os.path.exists(self.chrome_path):
                subprocess.Popen([self.chrome_path])
                time.sleep(1)
                return True
            else:
                # Try alternative methods
                try:
                    os.startfile("chrome")
                    time.sleep(1)
                    return True
                except:
                    try:
                        subprocess.Popen(["google-chrome"])
                        time.sleep(1)
                        return True
                    except:
                        try:
                            webbrowser.get('chrome').open('chrome://newtab')
                            time.sleep(1)
                            return True
                        except:
                            return False
        except Exception as e:
            print(f"Error launching Chrome: {e}")
            return False

    def wait_for_chrome(self, timeout=5):
        """Wait for Chrome window to appear"""
        start_time = time.time()
        while time.time() - start_time < timeout:
            chrome_windows = [window for window in gw.getWindowsWithTitle('Google Chrome') 
                            if 'Google Chrome' in window.title]
            if chrome_windows:
                return True
            time.sleep(0.5)
        return False

    def save_active_window(self):
        """Save currently active window"""
        try:
            self.last_active_window = gw.getActiveWindow()
        except:
            self.last_active_window = None

    def restore_active_window(self):
        """Restore previously active window"""
        if self.last_active_window:
            try:
                self.last_active_window.activate()
            except:
                pass

    def focus_chrome(self):
        """Enhanced Chrome window focusing"""
        try:
            self.save_active_window()
            chrome_windows = [window for window in gw.getWindowsWithTitle('Google Chrome') 
                            if 'Google Chrome' in window.title]
            
            if chrome_windows:
                chrome_windows[0].activate()
                chrome_windows[0].maximize()
                time.sleep(0.3)  # Increased delay for stability
                return True
            else:
                if self.launch_chrome():
                    if self.wait_for_chrome():
                        return self.focus_chrome()
                return False
                
        except Exception as e:
            print(f"Error focusing Chrome: {e}")
            return False

    def execute_sequence(self, sequence):
        """Execute a sequence of keyboard commands with retry"""
        if not self.focus_chrome():
            return False

        try:
            if isinstance(sequence, str):
                sequence = sequence.split(',')
            
            for cmd in sequence:
                cmd = cmd.strip()
                # Try the command up to 3 times
                for _ in range(3):
                    try:
                        keyboard.press_and_release(cmd)
                        time.sleep(0.2)  # Increased delay between commands
                        break
                    except:
                        time.sleep(0.1)
                        continue
            return True
        except Exception as e:
            print(f"Error executing sequence: {e}")
            return False

    def parse_command(self, query):
        """Enhanced command parsing with natural language understanding"""
        query = query.lower().strip()
        
        # Handle "open chrome" command first
        if any(phrase in query for phrase in ["open chrome", "launch chrome", "start chrome"]):
            return "launch", "chrome"
        
        # Handle special cases
        if "search" in query or "google" in query:
            search_terms = re.sub(r'^.*?(search|google|look up|find)\s+(?:for\s+)?', '', query)
            return "search", search_terms
            
        if "zoom" in query:
            if match := re.search(r'(?:zoom|scale)\s*(?:to|by)?\s*(\d+)(?:\s*%)?', query):
                level = int(match.group(1))
                return "zoom", level
                
        if "tab" in query and re.search(r'\d+', query):
            if match := re.search(r'(?:go to|switch to|open|show)\s+tab\s+(\d+)', query):
                return "tab_number", int(match.group(1))
        
        # Try to match command variations
        for base_command, variations in self.command_mappings.items():
            if any(variation in query for variation in variations + [base_command]):
                return "command", base_command
                
        return None, None

    def execute_command(self, query):
        """Enhanced command execution"""
        command_type, value = self.parse_command(query)
        
        if not command_type:
            return False, "Command not recognized"
            
        try:
            # Handle scroll commands
            if any(word in query.lower() for word in ["scroll", "move", "page up", "page down"]):
                return self.handle_scroll(query.lower())
            
            # Handle chrome launch
            if command_type == "launch" and value == "chrome":
                if self.launch_chrome() and self.wait_for_chrome():
                    return True, "Launched Google Chrome successfully"
                return False, "Failed to launch Chrome"
            
            # For all other commands, ensure Chrome is focused first
            if not self.focus_chrome():
                return False, "Could not focus Chrome window"
            
            if command_type == "search":
                return self.handle_search(value)
            elif command_type == "zoom":
                return self.handle_zoom(value)
            elif command_type == "tab_number":
                return self.handle_tab_number(value)
            elif command_type == "command":
                shortcut = self.shortcuts.get(value)
                if shortcut:
                    if self.execute_sequence(shortcut):
                        return True, f"Executed: {value}"
                    return False, f"Failed to execute: {value}"
            
            return False, "Command execution failed"
            
        except Exception as e:
            return False, f"Error executing command: {str(e)}"

    def handle_search(self, search_terms):
        """Enhanced search handling with better feedback"""
        try:
            if self.execute_sequence("ctrl+t"):
                time.sleep(0.3)
                search_url = f"https://www.google.com/search?q={quote(search_terms)}"
                keyboard.write(search_url)
                time.sleep(0.2)
                keyboard.press_and_release('enter')
                return True, f"Searching for: {search_terms}"
        except Exception as e:
            return False, f"Search failed: {str(e)}"

    def handle_zoom(self, level):
        """Handle zoom level adjustments"""
        try:
            current_level = 100
            if level > current_level:
                while current_level < level:
                    self.execute_sequence('ctrl+plus')
                    current_level += 10
            else:
                while current_level > level:
                    self.execute_sequence('ctrl+minus')
                    current_level -= 10
            return True, f"Zoom set to {level}%"
        except Exception as e:
            return False, f"Zoom adjustment failed: {str(e)}"

    def handle_tab_number(self, query):
        """Handle switching to specific tab numbers"""
        match = re.search(r'tab (\d+)', query)
        if match:
            num = int(match.group(1))
            if 1 <= num <= 8:
                if self.focus_chrome():
                    keyboard.press_and_release(f'ctrl+{num}')
                    return True, f"Switched to tab {num}"
        return False, "Invalid tab number"

    def handle_scroll(self, command):
        """Handle various scroll commands"""
        try:
            if not self.focus_chrome():
                return False, "Could not focus Chrome window"
            
            scroll_amount = 0
            smooth = False
            
            # Determine scroll behavior
            if "smooth" in command or "slowly" in command:
                smooth = True
                scroll_amount = 100  # pixels per step
            elif "half" in command:
                scroll_amount = 500
            elif "section" in command:
                scroll_amount = 800
            else:
                scroll_amount = 300  # default scroll amount
            
            # Determine direction
            direction = 1 if any(word in command for word in ["down", "bottom", "further"]) else -1
            
            if smooth:
                # Smooth scrolling
                steps = abs(scroll_amount) // 20
                for _ in range(steps):
                    pyautogui.scroll(direction * 20)
                    time.sleep(0.02)
            else:
                # Quick scrolling
                pyautogui.scroll(direction * scroll_amount)
            
            return True, f"Scrolled {'down' if direction > 0 else 'up'}"
            
        except Exception as e:
            return False, f"Scroll failed: {str(e)}"

    def handle_advanced_navigation(self, command):
        """Handle advanced navigation commands"""
        try:
            if not self.focus_chrome():
                return False, "Could not focus Chrome window"
            
            if "split screen" in command:
                # Handle split screen
                self.execute_sequence("windows+left")
                time.sleep(0.5)
                return True, "Split screen activated"
            
            elif "stack" in command:
                # Handle window stacking
                self.execute_sequence("windows+up")
                time.sleep(0.5)
                return True, "Windows stacked"
            
            elif "minimize others" in command:
                # Minimize other windows
                self.execute_sequence("windows+home")
                return True, "Other windows minimized"
            
            return False, "Navigation command not recognized"
            
        except Exception as e:
            return False, f"Navigation failed: {str(e)}"

# Create global instance
chrome_automation = ChromeAutomation()

def handle_chrome_command(query: str) -> str:
    """Enhanced Chrome command handler"""
    try:
        # Clean up the query
        query = query.lower().strip().rstrip('.')
        
        # Special handling for launch commands
        if any(phrase in query for phrase in ["open chrome", "launch chrome", "start chrome"]):
            success, message = chrome_automation.execute_command(query)
            if success:
                return f"✓ {message}"
            return f"⚠️ {message}"
        
        # Map some common variations to standard commands
        command_mappings = {
            "open history": "history",
            "show history": "history",
            "view history": "history",
            "open downloads": "downloads",
            "show downloads": "downloads",
            "view downloads": "downloads",
            "open bookmarks": "bookmarks",
            "show bookmarks": "bookmarks",
            "view bookmarks": "bookmarks",
        }
        
        # Try to map the command
        for cmd_variation, std_cmd in command_mappings.items():
            if cmd_variation in query:
                query = std_cmd
                break
        
        success, message = chrome_automation.execute_command(query)
        if success:
            return f"✓ {message}"
        else:
            return f"⚠️ {message}"
    except Exception as e:
        return f"❌ Chrome automation error: {str(e)}"

def ChromeCode(query):
    """Legacy support for existing code"""
    success, _ = chrome_automation.execute_command(query)
    return success