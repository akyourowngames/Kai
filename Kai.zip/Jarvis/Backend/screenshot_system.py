import pyautogui
import os
import datetime
from PIL import Image, ImageGrab
import keyboard
import numpy as np
from time import sleep
import cv2
from Frontend.GUI import ShowTextToScreen
from Backend.TextToSpeech import TextToSpeech

class ScreenshotSystem:
    def __init__(self):
        self.screenshot_dir = "Data/Screenshots"
        self.temp_dir = "Data/Temp"
        self.create_directories()
        self.selection_start = None
        self.selection_end = None
        self.is_selecting = False
        
    def create_directories(self):
        """Create necessary directories if they don't exist"""
        for directory in [self.screenshot_dir, self.temp_dir]:
            if not os.path.exists(directory):
                os.makedirs(directory)

    def generate_filename(self, prefix="screenshot", extension="png"):
        """Generate unique filename with timestamp"""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"{prefix}_{timestamp}.{extension}"

    def take_full_screenshot(self):
        """Take screenshot of entire screen"""
        try:
            filename = self.generate_filename()
            filepath = os.path.join(self.screenshot_dir, filename)
            screenshot = pyautogui.screenshot()
            screenshot.save(filepath)
            return filepath
        except Exception as e:
            print(f"Error taking full screenshot: {e}")
            return None

    def take_window_screenshot(self):
        """Take screenshot of active window"""
        try:
            import win32gui
            window = win32gui.GetForegroundWindow()
            if window:
                bbox = win32gui.GetWindowRect(window)
                screenshot = ImageGrab.grab(bbox)
                filepath = os.path.join(self.screenshot_dir, self.generate_filename("window"))
                screenshot.save(filepath)
                return filepath
        except Exception as e:
            print(f"Error taking window screenshot: {e}")
            return None

    def start_area_selection(self):
        """Start area selection process"""
        self.is_selecting = True
        self.selection_start = None
        self.selection_end = None
        
        # Create overlay window for selection
        cv2.namedWindow('Selection', cv2.WINDOW_NORMAL)
        cv2.setWindowProperty('Selection', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        
        # Take full screenshot for overlay
        screen = np.array(ImageGrab.grab())
        screen = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
        
        def mouse_callback(event, x, y, flags, param):
            if event == cv2.EVENT_LBUTTONDOWN:
                self.selection_start = (x, y)
            elif event == cv2.EVENT_LBUTTONUP:
                self.selection_end = (x, y)
                self.is_selecting = False
        
        cv2.setMouseCallback('Selection', mouse_callback)
        
        while self.is_selecting:
            display = screen.copy()
            if self.selection_start:
                cv2.circle(display, self.selection_start, 3, (0, 255, 0), -1)
                if not self.selection_end:
                    cv2.line(display, self.selection_start, (pyautogui.position()), (0, 255, 0), 1)
            cv2.imshow('Selection', display)
            if cv2.waitKey(1) & 0xFF == 27:  # ESC to cancel
                self.is_selecting = False
                self.selection_start = None
                self.selection_end = None
        
        cv2.destroyAllWindows()
        
        if self.selection_start and self.selection_end:
            return self.take_area_screenshot()
        return None

    def take_area_screenshot(self):
        """Take screenshot of selected area"""
        try:
            if not (self.selection_start and self.selection_end):
                return None
                
            x1, y1 = self.selection_start
            x2, y2 = self.selection_end
            left = min(x1, x2)
            top = min(y1, y2)
            width = abs(x2 - x1)
            height = abs(y2 - y1)
            
            screenshot = ImageGrab.grab(bbox=(left, top, left+width, top+height))
            filepath = os.path.join(self.screenshot_dir, self.generate_filename("area"))
            screenshot.save(filepath)
            return filepath
        except Exception as e:
            print(f"Error taking area screenshot: {e}")
            return None

    def process_screenshot_command(self, command):
        """Process screenshot commands"""
        try:
            command = command.lower()
            filepath = None
            message = ""

            if "full" in command or "entire" in command:
                filepath = self.take_full_screenshot()
                message = "Full screenshot taken"
            elif "window" in command or "active" in command:
                filepath = self.take_window_screenshot()
                message = "Window screenshot taken"
            elif "area" in command or "select" in command or "region" in command:
                ShowTextToScreen("Please select the area to capture...")
                filepath = self.start_area_selection()
                message = "Area screenshot taken"
            else:
                filepath = self.take_full_screenshot()
                message = "Screenshot taken"

            if filepath:
                message += f" and saved to {filepath}"
                ShowTextToScreen(message)
                TextToSpeech(message)
                return filepath
            else:
                error_msg = "Failed to take screenshot"
                ShowTextToScreen(error_msg)
                TextToSpeech(error_msg)
                return None

        except Exception as e:
            error_msg = f"Error processing screenshot command: {e}"
            ShowTextToScreen(error_msg)
            TextToSpeech(error_msg)
            return None

    def capture_with_delay(self, delay=3):
        """Take screenshot after a delay"""
        ShowTextToScreen(f"Taking screenshot in {delay} seconds...")
        sleep(delay)
        return self.take_full_screenshot()

    def capture_with_hotkey(self, hotkey='ctrl+shift+s'):
        """Set up hotkey for quick screenshots"""
        keyboard.add_hotkey(hotkey, self.take_full_screenshot)

# Initialize the screenshot system
screenshot_system = ScreenshotSystem()

# Example usage in main.py:
def handle_screenshot_command(command):
    return screenshot_system.process_screenshot_command(command) 