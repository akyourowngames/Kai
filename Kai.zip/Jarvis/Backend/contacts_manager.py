import json
import os
from pathlib import Path

class ContactsManager:
    def __init__(self):
        self.data_dir = Path("Data")
        self.contacts_file = self.data_dir / "whatsapp_contacts.json"
        self.ensure_data_directory()
        self.load_contacts()

    def ensure_data_directory(self):
        """Create Data directory if it doesn't exist"""
        self.data_dir.mkdir(exist_ok=True)
        if not self.contacts_file.exists():
            self.save_contacts({})

    def load_contacts(self):
        """Load contacts from JSON file"""
        try:
            with open(self.contacts_file, 'r', encoding='utf-8') as f:
                self.contacts = json.load(f)
        except Exception as e:
            print(f"Error loading contacts: {e}")
            self.contacts = {}

    def save_contacts(self, contacts=None):
        """Save contacts to JSON file"""
        if contacts is not None:
            self.contacts = contacts
        try:
            with open(self.contacts_file, 'w', encoding='utf-8') as f:
                json.dump(self.contacts, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f"Error saving contacts: {e}")

    def add_contact(self, name, phone, email=None, groups=None, notes=None):
        """Add or update a contact"""
        contact_key = name.lower()
        self.contacts[contact_key] = {
            "name": name,
            "phone": phone,
            "email": email or "",
            "groups": groups or [],
            "notes": notes or ""
        }
        self.save_contacts()
        return f"Added/Updated contact: {name}"

    def get_contact(self, name):
        """Get contact details by name"""
        return self.contacts.get(name.lower())

    def get_phone_number(self, name):
        """Get phone number for a contact"""
        contact = self.get_contact(name)
        return contact["phone"] if contact else None

    def delete_contact(self, name):
        """Delete a contact"""
        contact_key = name.lower()
        if contact_key in self.contacts:
            del self.contacts[contact_key]
            self.save_contacts()
            return f"Deleted contact: {name}"
        return f"Contact not found: {name}"

    def list_contacts(self, group=None):
        """List all contacts, optionally filtered by group"""
        if group:
            return {k: v for k, v in self.contacts.items() 
                   if group in v.get("groups", [])}
        return self.contacts

    def add_to_group(self, name, group):
        """Add contact to a group"""
        contact = self.get_contact(name)
        if contact:
            if "groups" not in contact:
                contact["groups"] = []
            if group not in contact["groups"]:
                contact["groups"].append(group)
            self.save_contacts()
            return f"Added {name} to group: {group}"
        return f"Contact not found: {name}" 