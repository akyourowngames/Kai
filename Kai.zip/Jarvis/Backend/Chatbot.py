from groq import Groq
from json import load, dump
import datetime
from dotenv import dotenv_values
import random
from Backend.location_system import LocationSystem

env_vars = dotenv_values(".env")

Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = "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"
client = Groq(api_key=GroqAPIKey)

messages = []

System = f"""Hello, I am {Username}, You are a very accurate and advanced AI chatbot named {Assistantname} which also has real-time up-to-date information from the internet.
*** Do not tell time until I ask, do not talk too much, just answer the question.***
*** Reply in only English, even if the question is in Hindi, reply in English.***
*** Do not provide notes in the output, just answer the question and never mention your training data. ***
"""

SystemChatBot = [
    {"role": "system", "content": System}
]

try: 
    with open(r'C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json', "r") as f:
        messages = load(f)
except FileNotFoundError:
    with open (r'C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json', "w") as f:
        dump([], f)
        
def RealTimeInformation():
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")
    
    data = f"Please use this real-time information if needed,\n"
    data += f"Day: {day}\nDate: {date}\nMonth: {month}\nYear: {year}\n"
    data += f"Time: {hour} hours: {minute} minutes: {second} seconds.\n"
    return data

def AnswerModifier(Answer):
    lines = Answer.split('\n')
    non_empty_lines = [line for line in lines if line.strip()]
    modified_answer = '\n'.join(non_empty_lines)
    return modified_answer

class Chatbot:
    def __init__(self):
        self.location_system = LocationSystem()

    def handle_location_query(self, query):
        """Handle location-related queries"""
        if "location" in query.lower():
            if "nearby" in query.lower():
                place_type = None
                for word in ["restaurant", "hospital", "school", "park", "shop"]:
                    if word in query.lower():
                        place_type = word
                        break
                return self.location_system.get_nearby_places(place_type)
            else:
                return self.location_system.get_location()

    def chat(self, query):
        try:
            # Handle special cases
            if "reminder" in query.lower():
                return "Sorry, I don't handle reminder queries."
            
            if "location" in query.lower():
                return self.handle_location_query(query)
            
            # Handle regular queries using Groq
            with open(r"C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json", "r") as f:
                messages = load(f)
                
            messages.append({"role": "user", "content": f"{query}"})
            
            completion = client.chat.completions.create(
                model="llama3-70b-8192",
                messages=SystemChatBot + [{"role": "system", "content": RealTimeInformation()}] + messages,
                max_tokens=1024,
                temperature=0.7,
                top_p=1,
                stream=True,
                stop=None
            )
            
            Answer = ""
            for chunk in completion:
                if chunk.choices[0].delta.content:
                    Answer += chunk.choices[0].delta.content
                    
            Answer = Answer.replace("</s>", "")
            
            messages.append({"role": "assistant", "content": Answer})
            
            with open(r"C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json", "w") as f:
                dump(messages, f, indent=4)
                
            return AnswerModifier(Answer=Answer)
            
        except Exception as e:
            print(f"Error in ChatBot: {str(e)}")
            with open(r"C:\Users\Krish\Desktop\Chatbot\Data\ChatLog.json", "w") as f:
                dump([], f, indent=4)
            return "I encountered an error. Please try asking your question again."

# Create a global instance of Chatbot
chatbot_instance = Chatbot()

# This function will be imported by main.py
def ChatBot(query):
    """Global function that uses the Chatbot class"""
    return chatbot_instance.chat(query)

if __name__ == "__main__":
    while True:
        user_input = input("Enter Your Question: ")
        print(ChatBot(user_input))