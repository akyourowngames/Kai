import json
import os
from pathlib import Path
from typing import Dict, List, Optional
import sqlite3
from datetime import datetime

class ContactManager:
    def __init__(self):
        self.initialize_database()
        self.load_default_contacts()
        
    def initialize_database(self):
        """Initialize SQLite database for contacts"""
        self.db_conn = sqlite3.connect('contacts.db')
        cursor = self.db_conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS contacts (
                id INTEGER PRIMARY KEY,
                name TEXT UNIQUE,
                email TEXT,
                category TEXT,
                company TEXT,
                last_used DATETIME,
                frequency INTEGER DEFAULT 0
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS aliases (
                id INTEGER PRIMARY KEY,
                contact_id INTEGER,
                alias TEXT UNIQUE,
                FOREIGN KEY (contact_id) REFERENCES contacts (id)
            )
        ''')
        
        self.db_conn.commit()

    def load_default_contacts(self):
        """Load default contacts from configuration"""
        default_contacts = {
            "krishna": "krishanjindal83@gmail.com",
            "dad": "dad@gmail.com",
            "boss": "boss@company.com",
            "team": "team@company.com",
            "hr": "hr@company.com",
            "support": "support@company.com"
        }
        
        cursor = self.db_conn.cursor()
        for name, email in default_contacts.items():
            cursor.execute('''
                INSERT OR IGNORE INTO contacts (name, email, category)
                VALUES (?, ?, 'default')
            ''', (name, email))
        
        self.db_conn.commit()

    def add_contact(self, name: str, email: str, aliases: List[str] = None, 
                   category: str = None, company: str = None) -> bool:
        """Add or update a contact"""
        try:
            cursor = self.db_conn.cursor()
            
            # Add main contact
            cursor.execute('''
                INSERT OR REPLACE INTO contacts (name, email, category, company)
                VALUES (?, ?, ?, ?)
            ''', (name.lower(), email, category, company))
            
            contact_id = cursor.lastrowid
            
            # Add aliases if provided
            if aliases:
                for alias in aliases:
                    cursor.execute('''
                        INSERT OR IGNORE INTO aliases (contact_id, alias)
                        VALUES (?, ?)
                    ''', (contact_id, alias.lower()))
            
            self.db_conn.commit()
            return True
        except Exception as e:
            print(f"Error adding contact: {e}")
            return False

    def get_email(self, name: str) -> Optional[str]:
        """Get email address from name or alias"""
        cursor = self.db_conn.cursor()
        
        # Try exact name match first
        cursor.execute('''
            SELECT email FROM contacts 
            WHERE LOWER(name) = LOWER(?)
        ''', (name,))
        result = cursor.fetchone()
        
        if result:
            self.update_contact_usage(name)
            return result[0]
        
        # Try alias match
        cursor.execute('''
            SELECT c.email 
            FROM contacts c
            JOIN aliases a ON c.id = a.contact_id
            WHERE LOWER(a.alias) = LOWER(?)
        ''', (name,))
        result = cursor.fetchone()
        
        if result:
            self.update_contact_usage(name)
            return result[0]
            
        return None

    def update_contact_usage(self, name: str):
        """Update contact usage statistics"""
        cursor = self.db_conn.cursor()
        cursor.execute('''
            UPDATE contacts 
            SET frequency = frequency + 1,
                last_used = CURRENT_TIMESTAMP
            WHERE LOWER(name) = LOWER(?)
        ''', (name,))
        self.db_conn.commit()

    def get_suggestions(self, partial_name: str) -> List[Dict]:
        """Get contact suggestions based on partial name"""
        cursor = self.db_conn.cursor()
        search_term = f"%{partial_name}%"
        
        cursor.execute('''
            SELECT name, email, category, company 
            FROM contacts 
            WHERE name LIKE ? OR email LIKE ?
            ORDER BY frequency DESC, last_used DESC
            LIMIT 5
        ''', (search_term, search_term))
        
        return [
            {
                "name": row[0],
                "email": row[1],
                "category": row[2],
                "company": row[3]
            }
            for row in cursor.fetchall()
        ]

    def __del__(self):
        """Cleanup database connection"""
        if hasattr(self, 'db_conn'):
            self.db_conn.close() 