from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.common.exceptions import TimeoutException, ElementNotInteractableException
import logging
import json
import time
import re

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('chrome_automation')

class ChromeVoiceAutomation:
    def __init__(self, headless=False):
        # Add default configuration
        self.config = {
            'chrome_commands': {
                'default_urls': {
                    'google': 'https://www.google.com',
                    'gmail': 'https://mail.google.com',
                    'youtube': 'https://www.youtube.com',
                    'maps': 'https://maps.google.com',
                    'drive': 'https://drive.google.com',
                    'calendar': 'https://calendar.google.com',
                    'translate': 'https://translate.google.com',
                    'photos': 'https://photos.google.com',
                    'docs': 'https://docs.google.com',
                    'sheets': 'https://sheets.google.com',
                    'slides': 'https://slides.google.com'
                }
            }
        }
        
        self.options = webdriver.ChromeOptions()
        if headless:
            self.options.add_argument('--headless')
        self.options.add_argument('--start-maximized')
        self.options.add_argument('--disable-notifications')  # Disable notifications
        self.options.add_argument('--disable-popup-blocking')  # Disable popup blocking
        self.driver = webdriver.Chrome(options=self.options)
        self.wait = WebDriverWait(self.driver, 10)
        self.actions = ActionChains(self.driver)
        self.current_tab = 0
        self.last_command = None
        
        # Open Google by default
        self.navigate_to("google")
    
    def navigate_to(self, url):
        """Smart navigation that handles both URLs and predefined sites"""
        if url in self.config['chrome_commands']['default_urls']:
            url = self.config['chrome_commands']['default_urls'][url]
        elif not url.startswith(('http://', 'https://')):
            url = f'https://{url}'
        self.driver.get(url)
        
    def find_input_field(self):
        """Find input field using multiple methods"""
        try:
            # Try different selectors for input fields
            selectors = [
                # Common input selectors
                "input[type='text']",
                "input:not([type='hidden'])",
                "textarea",
                "[contenteditable='true']",
                "[role='textbox']",
                # Google specific
                "input[name='q']",
                "textarea[name='q']",
                # Common search boxes
                "input[type='search']",
                ".search-box",
                "#search",
                # Generic content areas
                "div[contenteditable='true']",
                "iframe[contenteditable='true']"
            ]
            
            # Try each selector
            for selector in selectors:
                try:
                    elements = self.driver.find_elements(By.CSS_SELECTOR, selector)
                    visible_elements = [e for e in elements if e.is_displayed()]
                    if visible_elements:
                        return visible_elements[0]
                except:
                    continue
            
            # If no input found, try active element
            active = self.driver.switch_to.active_element
            if active.tag_name in ['input', 'textarea'] or active.get_attribute('contenteditable') == 'true':
                return active
            
            # Try focusing body and then getting active element
            body = self.driver.find_element(By.TAG_NAME, 'body')
            body.click()
            time.sleep(0.5)
            active = self.driver.switch_to.active_element
            if active.tag_name in ['input', 'textarea'] or active.get_attribute('contenteditable') == 'true':
                return active
                
            return None
        except Exception as e:
            logger.error(f"Error finding input field: {str(e)}")
            return None

    def find_clickable(self, text, timeout=5):
        """Smart element finder that tries multiple strategies"""
        # Convert text to lowercase for case-insensitive comparison
        text_lower = text.lower()
        
        # Special handling for Gmail compose
        if text_lower == "compose":
            strategies = [
                (By.CSS_SELECTOR, "div[role='button'][gh='cm']"),  # Gmail compose button
                (By.CSS_SELECTOR, ".T-I.T-I-KE.L3"),  # Alternative Gmail compose selector
                (By.XPATH, "//div[text()='Compose']"),  # Text-based compose
                (By.XPATH, "//div[@role='button' and contains(., 'Compose')]")  # Role-based compose
            ]
        else:
            strategies = [
                (By.XPATH, f"//*[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{text_lower}')]"),
                (By.XPATH, f"//button[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{text_lower}')]"),
                (By.XPATH, f"//a[contains(translate(text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{text_lower}')]"),
                (By.PARTIAL_LINK_TEXT, text),
                (By.CSS_SELECTOR, f"[aria-label*='{text}' i]"),
                (By.CSS_SELECTOR, f"[title*='{text}' i]"),
                (By.NAME, text)
            ]
        
        for by, selector in strategies:
            try:
                element = self.wait.until(EC.element_to_be_clickable((by, selector)))
                return element
            except:
                continue
        return None

    def smart_click(self, text):
        """Intelligent clicking that handles various scenarios"""
        element = self.find_clickable(text)
        if element:
            try:
                # Wait for element to be in viewport
                self.driver.execute_script("arguments[0].scrollIntoView(true);", element)
                time.sleep(0.5)  # Give time for any animations
                
                # Try multiple clicking methods
                try:
                    element.click()
                except:
                    try:
                        self.actions.move_to_element(element).click().perform()
                    except:
                        try:
                            self.driver.execute_script("arguments[0].click();", element)
                        except:
                            # Force click using JavaScript
                            self.driver.execute_script("""
                                var evt = document.createEvent('MouseEvents');
                                evt.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
                                arguments[0].dispatchEvent(evt);
                            """, element)
                return True
            except Exception as e:
                logger.error(f"Click error: {str(e)}")
        return False

    def process_voice_command(self, command):
        """Enhanced voice command processing"""
        try:
            command = command.lower().strip()
            logger.info(f"Processing command: {command}")
            
            # Handle gestures first
            if any(x in command for x in ["swipe", "pinch"]):
                return self.handle_gesture_command(command)
            
            # Handle smart navigation
            elif any(x in command for x in ["go to", "open", "navigate"]):
                return self.handle_smart_navigation(command)
            
            # Handle advanced tab management
            elif any(x in command for x in ["tab", "window", "duplicate", "merge"]):
                return self.handle_tab_management(command)
            
            # Handle other commands
            elif "scroll" in command:
                return self.handle_scroll_command(command)
            elif "refresh" in command or "reload" in command:
                return self.handle_misc_command(command)
            elif any(x in command for x in ["type", "write", "search", "google"]):
                return self.handle_typing_command(command)
            elif "zoom" in command:
                return self.handle_zoom_command(command)
            
            return "Command not recognized"
            
        except Exception as e:
            logger.error(f"Command processing error: {str(e)}")
            return f"Error processing command: {str(e)}"

    def process_single_command(self, command):
        """Process a single command"""
        if any(keyword in command for keyword in ["type", "write", "search for", "find"]):
            return self.handle_typing_command(command)
        elif any(keyword in command for keyword in ["click", "press", "select"]):
            return self.handle_click_command(command)
        elif "scroll" in command:
            return self.handle_scroll_command(command)
        elif any(keyword in command for keyword in ["tab", "window"]):
            return self.handle_tab_command(command)
        elif any(keyword in command for keyword in ["go to", "open", "navigate"]):
            return self.handle_navigation_command(command)
        elif "zoom" in command:
            return self.handle_zoom_command(command)
        else:
            return self.handle_misc_command(command)

    def handle_typing_command(self, command):
        """Enhanced typing command handler"""
        try:
            # Extract text and determine if search is needed
            text = ""
            should_search = False
            
            if "google search" in command:
                text = command.replace("google search", "").strip()
                should_search = True
            elif "search for" in command:
                text = command.replace("search for", "").strip()
                should_search = True
            elif "type" in command:
                text = command.split("type")[-1].strip()
                should_search = "search" in command
            elif "write" in command:
                text = command.split("write")[-1].strip()
                should_search = "search" in command
            
            # Go to Google if it's a search
            if should_search and "google.com" not in self.driver.current_url:
                self.driver.get("https://www.google.com")
                time.sleep(2)  # Wait longer for page load
            
            # Find input field using multiple methods
            input_element = None
            try:
                # Method 1: Direct Google search box
                input_element = self.wait.until(
                    EC.presence_of_element_located((By.NAME, "q"))
                )
            except:
                try:
                    # Method 2: Any visible input field
                    input_element = self.wait.until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, "input[type='text']:not([hidden])"))
                    )
                except:
                    try:
                        # Method 3: Any editable element
                        input_element = self.wait.until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, "[contenteditable='true']"))
                        )
                    except:
                        return "Could not find input field"
            
            # Make sure element is interactable
            self.wait.until(EC.element_to_be_clickable(input_element))
            
            # Click the element first
            try:
                input_element.click()
            except:
                self.driver.execute_script("arguments[0].click();", input_element)
            
            time.sleep(0.5)  # Wait after click
            
            # Clear existing text
            try:
                input_element.clear()
            except:
                input_element.send_keys(Keys.CONTROL + "a")  # Select all
                input_element.send_keys(Keys.DELETE)  # Delete selection
            
            time.sleep(0.5)  # Wait after clearing
            
            # Type the text
            input_element.send_keys(text)
            time.sleep(0.5)  # Wait after typing
            
            # Search if needed
            if should_search:
                input_element.send_keys(Keys.RETURN)
                time.sleep(1)  # Wait for search results
                return f"Searched for: {text}"
            
            return f"Typed: {text}"
            
        except Exception as e:
            logger.error(f"Typing error: {str(e)}")
            return f"Error typing text: {str(e)}"

    def handle_click_command(self, command):
        text = command.split("click")[-1].strip() if "click" in command else command.split("press")[-1].strip()
        
        if self.smart_click(text):
            return f"Clicked on {text}"
        return f"Could not find element to click: {text}"

    def handle_scroll_command(self, command):
        if "top" in command:
            self.driver.execute_script("window.scrollTo(0, 0)")
            return "Scrolled to top"
        elif "bottom" in command:
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight)")
            return "Scrolled to bottom"
        elif "up" in command:
            amount = -500
            if any(str(i) for i in range(10) if str(i) in command):
                amount = -int(re.findall(r'\d+', command)[0]) * 100
            self.driver.execute_script(f"window.scrollBy(0, {amount});")
            return "Scrolled up"
        elif "down" in command:
            amount = 500
            if any(str(i) for i in range(10) if str(i) in command):
                amount = int(re.findall(r'\d+', command)[0]) * 100
            self.driver.execute_script(f"window.scrollBy(0, {amount});")
            return "Scrolled down"

    def handle_tab_command(self, command):
        if "new" in command:
            self.driver.execute_script("window.open('');")
            self.driver.switch_to.window(self.driver.window_handles[-1])
            self.navigate_to("google")
            return "Opened new tab"
        elif "close" in command:
            self.driver.close()
            if self.driver.window_handles:
                self.driver.switch_to.window(self.driver.window_handles[0])
            return "Closed current tab"
        elif "next" in command or "right" in command:
            current_index = self.driver.window_handles.index(self.driver.current_window_handle)
            next_index = (current_index + 1) % len(self.driver.window_handles)
            self.driver.switch_to.window(self.driver.window_handles[next_index])
            return "Switched to next tab"
        elif "previous" in command or "left" in command:
            current_index = self.driver.window_handles.index(self.driver.current_window_handle)
            prev_index = (current_index - 1) % len(self.driver.window_handles)
            self.driver.switch_to.window(self.driver.window_handles[prev_index])
            return "Switched to previous tab"

    def handle_navigation_command(self, command):
        url = command.split("go to")[-1].strip() if "go to" in command else command.split("open")[-1].strip()
        try:
            # Special handling for Gmail
            if "gmail" in url.lower():
                self.navigate_to("gmail")
                # Wait for Gmail to load
                time.sleep(3)  # Give Gmail extra time to load
                try:
                    # Wait for the Gmail loading screen to disappear
                    self.wait.until(EC.invisibility_of_element_located((By.CSS_SELECTOR, ".loading")))
                    # Wait for the main Gmail interface to be present
                    self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".ain")))
                except:
                    pass  # Continue even if waiting fails
                return "Navigated to Gmail"
            else:
                self.navigate_to(url)
                return f"Navigated to {url}"
        except Exception as e:
            logger.error(f"Navigation error: {str(e)}")
            return f"Failed to navigate to {url}"

    def handle_zoom_command(self, command):
        if "in" in command:
            self.actions.key_down(Keys.CONTROL).send_keys(Keys.ADD).key_up(Keys.CONTROL).perform()
            return "Zoomed in"
        elif "out" in command:
            self.actions.key_down(Keys.CONTROL).send_keys(Keys.SUBTRACT).key_up(Keys.CONTROL).perform()
            return "Zoomed out"
        elif "reset" in command:
            self.actions.key_down(Keys.CONTROL).send_keys('0').key_up(Keys.CONTROL).perform()
            return "Zoom reset"

    def handle_misc_command(self, command):
        if "refresh" in command or "reload" in command:
            self.driver.refresh()
            return "Page refreshed"
        elif "back" in command:
            self.driver.back()
            return "Navigated back"
        elif "forward" in command:
            self.driver.forward()
            return "Navigated forward"
        else:
            return "Command not recognized"

    def handle_gesture_command(self, command):
        """Handle gesture-based commands"""
        try:
            if "swipe" in command:
                if "left" in command:
                    self.actions.key_down(Keys.ALT).send_keys(Keys.LEFT).key_up(Keys.ALT).perform()
                    return "Swiped left (back)"
                elif "right" in command:
                    self.actions.key_down(Keys.ALT).send_keys(Keys.RIGHT).key_up(Keys.ALT).perform()
                    return "Swiped right (forward)"
            
            elif "pinch" in command:
                if "in" in command:
                    self.actions.key_down(Keys.CONTROL).send_keys(Keys.ADD).key_up(Keys.CONTROL).perform()
                    return "Pinched in (zoom in)"
                elif "out" in command:
                    self.actions.key_down(Keys.CONTROL).send_keys(Keys.SUBTRACT).key_up(Keys.CONTROL).perform()
                    return "Pinched out (zoom out)"
            
            return "Gesture not recognized"
        except Exception as e:
            logger.error(f"Gesture error: {str(e)}")
            return "Error performing gesture"

    def handle_smart_navigation(self, command):
        """Smart navigation with shortcuts and bookmarks"""
        try:
            # Extract destination
            destination = command.split("to")[-1].strip() if "to" in command else command.split("open")[-1].strip()
            
            # Common website shortcuts
            shortcuts = {
                "mail": "gmail.com",
                "email": "gmail.com",
                "videos": "youtube.com",
                "maps": "google.com/maps",
                "news": "news.google.com",
                "drive": "drive.google.com",
                "photos": "photos.google.com",
                "calendar": "calendar.google.com",
                "meet": "meet.google.com",
                "chat": "chat.google.com",
                "docs": "docs.google.com",
                "sheets": "sheets.google.com",
                "slides": "slides.google.com"
            }
            
            # Check shortcuts
            for key, url in shortcuts.items():
                if key in destination.lower():
                    self.navigate_to(url)
                    return f"Navigated to {url}"
            
            # Handle social media
            social_media = {
                "facebook": "facebook.com",
                "twitter": "twitter.com",
                "instagram": "instagram.com",
                "linkedin": "linkedin.com",
                "reddit": "reddit.com"
            }
            
            for platform, url in social_media.items():
                if platform in destination.lower():
                    self.navigate_to(url)
                    return f"Navigated to {url}"
            
            # Default to Google search if not found
            if not destination.startswith(("http://", "https://")):
                search_url = f"https://www.google.com/search?q={destination}"
                self.navigate_to(search_url)
                return f"Searched for {destination}"
            
        except Exception as e:
            logger.error(f"Navigation error: {str(e)}")
            return "Error during navigation"

    def handle_tab_management(self, command):
        """Advanced tab management"""
        try:
            if "duplicate" in command:
                current_url = self.driver.current_url
                self.driver.execute_script("window.open('');")
                self.driver.switch_to.window(self.driver.window_handles[-1])
                self.driver.get(current_url)
                return "Duplicated current tab"
            
            elif "restore" in command:
                self.driver.execute_script("window.history.go(-1);")
                return "Restored last closed tab"
            
            elif "move" in command:
                if "left" in command:
                    self.driver.execute_script("window.moveBy(-100, 0);")
                    return "Moved tab left"
                elif "right" in command:
                    self.driver.execute_script("window.moveBy(100, 0);")
                    return "Moved tab right"
                
            elif "merge" in command:
                if len(self.driver.window_handles) > 1:
                    main_window = self.driver.current_window_handle
                    for handle in self.driver.window_handles:
                        if handle != main_window:
                            self.driver.switch_to.window(handle)
                            current_url = self.driver.current_url
                            self.driver.close()
                            self.driver.switch_to.window(main_window)
                            self.driver.execute_script(f"window.open('{current_url}');")
                    return "Merged all tabs"
                
            return self.handle_tab_command(command)
            
        except Exception as e:
            logger.error(f"Tab management error: {str(e)}")
            return "Error managing tabs"

    def close(self):
        """Close the browser"""
        try:
            self.driver.quit()
        except:
            pass 