import pygetwindow as gw
from time import sleep

while 1:
    try:
        Currrent_APP = gw.getActiveWindowTitle()
    except gw.PyGetWindowException:
        Currrent_APP = ""
    sleep(1)
    print(Currrent_APP.split(" - "))