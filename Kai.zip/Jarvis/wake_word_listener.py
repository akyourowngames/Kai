import pvporcupine
import pyaudio
import struct
import subprocess
import sys
import os
from dotenv import dotenv_values

# Load environment variables
env_vars = dotenv_values(".env")
ACCESS_KEY = env_vars.get("WakeWordAPIKey")

def listen_for_kai():
    """Standalone wake word detector that starts main.py when wake word is detected"""
    try:
        # Initialize Porcupine with default wake words
        porcupine = pvporcupine.create(
            access_key=ACCESS_KEY,
            keywords=["alexa", "hey google", "jarvis", "computer"]  # Using default keywords
        )
        
        # Initialize audio stream
        pa = pyaudio.PyAudio()
        audio_stream = pa.open(
            rate=porcupine.sample_rate,
            channels=1,
            format=pyaudio.paInt16,
            input=True,
            frames_per_buffer=porcupine.frame_length
        )

        print("🎧 Listening for wake words...")
        print("Available wake words: 'alexa', 'hey google', 'jarvis', 'computer'")
        print("Press Ctrl+C to exit")
        
        while True:
            # Read audio
            pcm = audio_stream.read(porcupine.frame_length)
            pcm = struct.unpack_from("h" * porcupine.frame_length, pcm)

            # Process audio
            keyword_index = porcupine.process(pcm)
            
            # If wake word detected
            if keyword_index >= 0:
                print("🎉 Wake word detected! Starting main.py...")
                
                try:
                    # Get the path to main.py
                    main_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py")
                    
                    # Check if main.py exists
                    if not os.path.exists(main_path):
                        print(f"❌ Error: main.py not found at {main_path}")
                        continue
                    
                    # Kill any existing main.py process
                    if sys.platform == "win32":
                        os.system('taskkill /F /IM "python.exe" /FI "WINDOWTITLE eq KAI Assistant"')
                    else:
                        os.system("pkill -f main.py")
                    
                    # Start main.py in a new process
                    subprocess.Popen([sys.executable, main_path],
                                  stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE,
                                  creationflags=subprocess.CREATE_NEW_CONSOLE)
                    
                    print("✅ Successfully started main.py")
                    
                except Exception as e:
                    print(f"❌ Error starting main.py: {str(e)}")

    except Exception as e:
        print(f"❌ Error in wake word detection: {str(e)}")
    finally:
        # Clean up resources
        if 'audio_stream' in locals():
            audio_stream.close()
        if 'pa' in locals():
            pa.terminate()
        if 'porcupine' in locals():
            porcupine.delete()

if __name__ == "__main__":
    try:
        listen_for_kai()
    except KeyboardInterrupt:
        print("\n👋 Shutting down wake word listener...")
    except Exception as e:
        print(f"❌ Error: {str(e)}") 