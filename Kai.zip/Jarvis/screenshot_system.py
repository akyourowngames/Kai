import pyautogui
import os
from datetime import datetime
import cv2
import numpy as np
from PIL import Image
import pytesseract
from pynput import mouse, keyboard
import threading

class ScreenshotSystem:
    def __init__(self):
        self.screenshot_dir = "Data/screenshots"
        self.recording = False
        self.selection_start = None
        self.selection_end = None
        os.makedirs(self.screenshot_dir, exist_ok=True)
    
    def take_full_screenshot(self):
        """Take screenshot of entire screen"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshot_dir}/screenshot_{timestamp}.png"
        screenshot = pyautogui.screenshot()
        screenshot.save(filename)
        return f"Full screenshot saved: {filename}"
    
    def take_window_screenshot(self):
        """Take screenshot of active window"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshot_dir}/window_{timestamp}.png"
        
        # Get active window
        window = pyautogui.getActiveWindow()
        if window:
            screenshot = pyautogui.screenshot(region=(
                window.left, window.top, 
                window.width, window.height
            ))
            screenshot.save(filename)
            return f"Window screenshot saved: {filename}"
        return "No active window found"
    
    def start_area_selection(self):
        """Start area selection for screenshot"""
        self.selection_start = None
        self.selection_end = None
        
        def on_click(x, y, button, pressed):
            if button == mouse.Button.left:
                if pressed:
                    self.selection_start = (x, y)
                else:
                    self.selection_end = (x, y)
                    return False
        
        # Start listener
        with mouse.Listener(on_click=on_click) as listener:
            listener.join()
        
        if self.selection_start and self.selection_end:
            return self.take_area_screenshot()
        return "Area selection cancelled"
    
    def take_area_screenshot(self):
        """Take screenshot of selected area"""
        if not self.selection_start or not self.selection_end:
            return "No area selected"
        
        x1, y1 = self.selection_start
        x2, y2 = self.selection_end
        
        # Calculate region
        left = min(x1, x2)
        top = min(y1, y2)
        width = abs(x2 - x1)
        height = abs(y2 - y1)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshot_dir}/area_{timestamp}.png"
        
        screenshot = pyautogui.screenshot(region=(left, top, width, height))
        screenshot.save(filename)
        return f"Area screenshot saved: {filename}"
    
    def extract_text_from_image(self, image_path):
        """Extract text from screenshot using OCR"""
        try:
            image = Image.open(image_path)
            text = pytesseract.image_to_string(image)
            return text.strip()
        except Exception as e:
            return f"Error extracting text: {str(e)}"
    
    def start_screen_recording(self, duration=None):
        """Start screen recording"""
        if self.recording:
            return "Recording already in progress"
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshot_dir}/recording_{timestamp}.avi"
        
        # Get screen size
        screen_size = pyautogui.size()
        
        # Initialize video writer
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        out = cv2.VideoWriter(filename, fourcc, 20.0, screen_size)
        
        self.recording = True
        
        def record():
            start_time = datetime.now()
            while self.recording:
                if duration and (datetime.now() - start_time).seconds >= duration:
                    self.recording = False
                    break
                
                # Capture frame
                frame = pyautogui.screenshot()
                frame = cv2.cvtColor(np.array(frame), cv2.COLOR_RGB2BGR)
                out.write(frame)
            
            out.release()
        
        # Start recording in thread
        threading.Thread(target=record).start()
        return f"Started recording: {filename}"
    
    def stop_screen_recording(self):
        """Stop screen recording"""
        if self.recording:
            self.recording = False
            return "Recording stopped"
        return "No recording in progress" 